title: Apollo配置中心搭建 & SpringBoot整合Apollo客户端
date: '2019-07-23 16:21:00'
updated: '2019-07-23 16:21:00'
tags: [Apollo]
permalink: /articles/2019/07/23/1565048869593.html
---
# Apollo配置中心介绍

[Apollo配置中心介绍]([https://github.com/ctripcorp/apollo/wiki/Apollo%E9%85%8D%E7%BD%AE%E4%B8%AD%E5%BF%83%E4%BB%8B%E7%BB%8D](https://github.com/ctripcorp/apollo/wiki/Apollo配置中心介绍))

# Apollo配置中心搭建

配置中心包括`server sevice`、`admin service`、`portal web`三个项目。其中`apollo portal`是一个`web`应用，运维人员可通过它进行配置的编辑和发布；`server`默认暴露`8090`为`apollo portal`提供服务；`config server`则通过`8080`端口为`apollo client`（也即应用）提供服务（如定时拉取配置信息、监听`apollo portal`的发布消息）。

`server service`和`admin service`都需要连接数据库。

## 环境准备

- `centos6.7 desktop`

  - `jdk1.8+`
  - 确保正确的网络配置以使虚拟机能和本地通信，网络配置可参考 [Linux问题汇总](http://www.zhenganwen.top/posts/a3cd5124/)

- `mysql5.6.5+`

  - 可以是本地的，也可以是虚拟机上的。如果是本地的，注意安装在虚拟机上的配置中心能否到，可以配置`root`使用`123456`从任何主机连接到本地`mysql`服务器

    ```sql
    mysql>GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY '123456' WITH GRANT OPTION;
    mysql>FLUSH RIVILEGES
    ```

- 下载配置中心安装包`apollo-build-scripts-master`

  - https://github.com/nobodyiam/apollo-build-scripts/archive/master.zip

- 下载`apollo client`依赖包`apollo-master`

  - https://github.com/ctripcorp/apollo/archive/master.zip

## 安装步骤

### 1.创建数据库

将`apollo-master\scripts\sql`下的两个`sql`文件在`mysql`中执行一遍，会生成两个数据库

### 2.更改配置中心启动脚本

将`apollo-build-scripts-master.zip`上传到`centos`的`/usr/local/software`（目录不存在可自行创建），`unzip apollo-build-scripts-master.zip`解压（若没有安装可通过`yum -y install unzip`安装`unzip`命令）

修改启动脚本`apollo-build-scripts-master/demo.sh`（将连接数据库的`IP`、用户名、密码修改为你自己的，我的`mysql`是装在本地的，而本地的`vmnet8`的`ip`配置为了`192.168.101.2`，关于宿主机和虚拟机的通信以及IP配置等可参考[Linux问题汇总](http://www.zhenganwen.top/posts/a3cd5124/)）

```shell
# apollo config db info
apollo_config_db_url=jdbc:mysql://192.168.102.2:3306/ApolloConfigDB?characterEncoding=utf8
apollo_config_db_username=root
apollo_config_db_password=123456

# apollo portal db info
apollo_portal_db_url=jdbc:mysql://192.168.102.2:3306/ApolloPortalDB?characterEncoding=utf8
apollo_portal_db_username=root
apollo_portal_db_password=123456
```

### 3.通过启动脚本启动apollo配置中心

`./demo.sh start`，若出现如下提示则说明启动成功

```shell
[root@localhost apollo-build-scripts-master]# ./demo.sh start
==== starting service ====
Service logging file is ./service/apollo-service.log
Started [29110]
Waiting for config service startup.......
Config service started. You may visit http://localhost:8080 for service status now!
Waiting for admin service startup.....
Admin service started
==== starting portal ====
Portal logging file is ./portal/apollo-portal.log
Started [29304]
Waiting for portal startup.......
Portal started. You can visit http://localhost:8070 now!
```

> 启动失败的原因可到`apollo-build-scripts-master/service/apollo-service.log`查看，常见问题如下
>
> - 给虚拟机设置的运行内存过低，由于阿波罗配置中心会启动三个项目（`config service`、`admin service`、`portal web`），因此建议将内存给到2G
>
> - 如果你的`mysql`安装在本地，而虚拟机的阿波罗配置中心再启动时需要连接该数据库，虚拟机防火墙、`mysql`访问权限等原因会导致连接失败，进而导致启动失败
>
>   防火墙关闭命令：`service iptables stop`

如果你启动成功，就可以通过`http://192.168.102.101:8070`来访问`portal web`了（我的虚拟机IP为`192.168.102.101`）

至此，阿波罗的配置中心就搭建完成了

# SpringBoot整合Apollo客户端实现从配置中心读取配置信息及配置中心更改配置后通知客户端实时更新

### 1.安装apollo依赖到本地或私服

我们的应用要想连接配置中西，需要引入`apollo-client`和`apollo-core`这两个依赖，而这两者在中心仓库是找不到的，因此我们需要打包到本地。这一步双击`apollo-master\scripts\build.bat`构建脚本即可。（事先确保本地已安装配置好了`maven`环境变量`mvn`）

### 2.创建maven项目，引入SpringBoot和apollo客户端依赖

复制以下代码到你的`pom`

```xml
<parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>2.0.1.RELEASE</version>
    <relativePath /> <!-- lookup parent from repository -->
</parent>

<properties>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    <project.reporting.outputEncoding>UTF-8</project.reporting.outputEncoding>
    <java.version>1.8</java.version>
    <spring-cloud.version>Finchley.RC1</spring-cloud.version>
</properties>
<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>

    <!-- apollo 携程apollo配置中心框架 -->
    <dependency>
        <groupId>com.ctrip.framework.apollo</groupId>
        <artifactId>apollo-client</artifactId>
        <version>1.0.0</version>
    </dependency>
    <dependency>
        <groupId>com.ctrip.framework.apollo</groupId>
        <artifactId>apollo-core</artifactId>
        <version>1.0.0</version>
    </dependency>


    <dependency>
        <groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId>
        <optional>true</optional>
    </dependency>
    <dependency>
        <groupId>com.alibaba</groupId>
        <artifactId>fastjson</artifactId>
        <version>1.2.3</version>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
    </dependency>
</dependencies>

<dependencyManagement>
    <dependencies>
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-dependencies</artifactId>
            <version>${spring-cloud.version}</version>
            <type>pom</type>
            <scope>import</scope>
        </dependency>
    </dependencies>
</dependencyManagement>

<build>
    <plugins>
        <plugin>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-maven-plugin</artifactId>
        </plugin>
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-compiler-plugin</artifactId>
            <configuration>
                <source>1.8</source>
                <target>1.8</target>
            </configuration>
        </plugin>
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-resources-plugin</artifactId>
            <version>3.0.1</version>
            <executions>
                <execution>
                    <id>copy-conf</id>
                    <phase>package</phase>
                    <goals>
                        <goal>copy-resources</goal>
                    </goals>
                    <configuration>
                        <encoding>UTF-8</encoding>
                        <outputDirectory>${project.build.directory}/ext/conf</outputDirectory>
                        <resources>
                            <resource>
                                <directory>ext/conf</directory>
                                <includes>
                                    <include>logback.xml</include>
                                </includes>
                                <filtering>true</filtering>
                            </resource>
                        </resources>
                    </configuration>
                </execution>
            </executions>
        </plugin>
        <plugin>
            <groupId>org.jacoco</groupId>
            <artifactId>jacoco-maven-plugin</artifactId>
            <version>0.7.5.201505241946</version>
            <executions>
                <execution>
                    <id>default-prepare-agent</id>
                    <goals>
                        <goal>prepare-agent</goal>
                    </goals>
                </execution>
                <execution>
                    <id>default-prepare-agent-integration</id>
                    <goals>
                        <goal>prepare-agent-integration</goal>
                    </goals>
                </execution>
            </executions>
        </plugin>
        <plugin>
            <groupId>com.spotify</groupId>
            <artifactId>docker-maven-plugin</artifactId>
            <version>0.4.3</version>
            <configuration>
                <imageName>hy_uav_gateway</imageName>
                <dockerDirectory>src/main/docker</dockerDirectory>
                <resources>
                    <resource>
                        <targetPath>/</targetPath>
                        <directory>${project.build.directory}</directory>
                        <include>${project.build.finalName}.jar</include>
                        <include>ext/conf/logback.xml</include>
                    </resource>
                </resources>
            </configuration>
        </plugin>
    </plugins>
</build>

<repositories>
    <repository>
        <id>spring-milestones</id>
        <name>Spring Milestones</name>
        <url>https://repo.spring.io/milestone</url>
        <snapshots>
            <enabled>false</enabled>
        </snapshots>
    </repository>
</repositories>
```

### 3.在portal web中新建项目

访问`http://192.168.102.101:8070`，可使用默认提供的用户名`apollo`和密码`admin`来登录，然后创建项目（这里的项目就相当于对应一个微服务应用）

![](https://user-gold-cdn.xitu.io/2019/7/23/16c1e2bf532ca46f?w=1046&h=617&f=png&s=69707)

阿波罗会为你的这个项目默认生成一个`DEV`环境，你可以通过`新增配置按钮`来新增配置项、通过`发布`按钮发布新建的配置项。阿波罗客户端启动时会读取发布状态的配置项，如果在应用运行时发布修改过的或新增的配置项，应用也会通过`tcp`长连接监听到并及时同步。

这里我新增一个`name`的配置项

![](https://user-gold-cdn.xitu.io/2019/7/23/16c1e3443b5e3cfb?w=1358&h=761&f=png&s=73557)

然后点击`发布`按钮。

### 4.添加apollo默认读取的配置文件

新建`src/main/resources/META-INFO/app.properties`

```properties
app.id=appId_1001	//新建项目时填写的应用Id
```

新建`src/main/resources/apollo-env.properties`

```properties
local.meta=http://192.168.102.101:8080	//将IP更改为你虚拟机的IP
dev.meta=http://192.168.102.101:8080	//将IP更改为你虚拟机的IP
fat.meta=${fat_meta}
uat.meta=${uat_meta}
lpt.meta=${lpt_meta}
pro.meta=${pro_meta}
```

新建`C:\opt\settings\server.properties`用来指定读取配置中心的哪个环境
```properties
env=DEV
```
> 这个路径和文件名不能有丝毫差错，应用启动时，阿波罗客户端会读取该文件

### 5.通过@EnableApolloConfig启用apollo客户端，通过@Value注解读取配置信息

```java
package top.zhenganwen.demo.apollo;

import com.ctrip.framework.apollo.spring.annotation.EnableApolloConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@EnableApolloConfig
@RestController
@SpringBootApplication
public class Application {

    @Value("${name:test}")//读取不到，默认赋值为test，避免应用启动报错
    String name;

    @RequestMapping("apollo")
    public String apollo() {
        return name;
    }

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}

```

### 6.测试

- 访问`http://localhost:8080/apollo`，浏览器返回`zhenganwen`，应用从配置中心读取配置信息成功。
- 在`protal web`中编辑`name`配置项，更改`value`为`zhangsan`，并点击`发布`，再次访问`http://localhost:8080/apollo`，返回`zhangsan`，热更新测试成功