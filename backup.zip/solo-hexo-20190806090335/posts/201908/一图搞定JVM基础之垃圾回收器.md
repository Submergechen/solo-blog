title: 一图搞定JVM基础之垃圾回收器
date: '2019-08-06 08:35:33'
updated: '2019-08-06 08:35:33'
tags: [JVM]
permalink: /articles/2019/08/06/1565051733371.html
---
![](https://img.hacpai.com/bing/20180103.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

![GarbageCollector.png](https://img.hacpai.com/file/2019/08/GarbageCollector-b513cbee.png)
