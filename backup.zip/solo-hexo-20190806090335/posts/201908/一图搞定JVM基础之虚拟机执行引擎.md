title: 一图搞定JVM基础之虚拟机执行引擎
date: '2019-08-06 08:40:31'
updated: '2019-08-06 08:41:30'
tags: [JVM]
permalink: /articles/2019/08/06/1565052030988.html
---
![](https://img.hacpai.com/bing/20190716.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

![VM Execution Engine](https://user-gold-cdn.xitu.io/2019/8/4/16c5bb96aadf11ea?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)