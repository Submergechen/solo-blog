title: SpringCloud（八）路由网关
date: '2018-08-02 16:21:11'
updated: '2018-08-02 16:21:11'
tags: [SpringCloud]
permalink: /articles/2018/08/02/1565048865721.html
---
<!-- more -->

# 概述

`Zuul`包含了对请求的**路由**和**过滤**两个最主要的功能。

其中**路由功能负责将外部请求转发到具体的微服务实例上**,是**实现外部访问统一入口的基础**,而过**滤器功能则负责对请求的处理过程进行干预,是实现请求校验,服务聚合等功能的基础**.

**Zuul和Eureka进行整合**,**将Zuul自身注册为Eureka服务治理下的应用**,同时从`Eureka`中获得其他微服务的消息,也即**以后的访问微服务都是通过Zuul跳转后获得**.


**注意**:`Zuul`服务最终还是会注册进`Eureka`

提供**代理+路由+过滤**三大功能

[官网资料](https://github.com/Netflix/zuul/wiki/Getting-Started)

> 打个形象的比喻：拿写字楼的物业、入驻写字楼的企业、写字楼的门卫来做比，企业就是提供服务的一个个微服务，物业就是 `Eureka Server`，企业微服务要入住先要在物业那儿注册，而门卫就是 `Zuul`，客户要找企业寻求服务就要先通过门卫转发诉求而不能直接去企业办公室。门卫（前台）就是楼层所有企业服务的**代理**，客户诉求通过后前台带客户去相应的企业办公室，这就是**路由**。门卫不会让闲杂人等进入楼层，这就是**过滤**。

---------

# 实战

## zuul基本配置

1. 新建 `clouddemo-zuul-gateway`工程

2. 添加依赖 `eureka`、`zuul`（`zuul`也是作为一个微服务注册到 `eureka`）

   ```xml
   <dependency>
       <groupId>org.springframework.cloud</groupId>
       <artifactId>spring-cloud-starter-zuul</artifactId>
   </dependency>
   <dependency>
       <groupId>org.springframework.cloud</groupId>
       <artifactId>spring-cloud-starter-eureka</artifactId>
   </dependency>
   <dependency>
       <groupId>org.springframework.cloud</groupId>
       <artifactId>spring-cloud-starter-config</artifactId>
   </dependency>
   ```

3. 添加配置

   1. 服务名 `spring.application.name`
   2. 通过 `eureka`客户端连接 `eureka server`
   3. 注册的服务实例ID `instance-id`
   4. `zuul`代理服务以及映射路由

   ```yaml
   server:
     port: 9527
   
   spring:
      application:
       name: clouddemo-zuul-gateway
   
   eureka:
     instance:
       instance-id: clouddemo-zuul-gateway-9527
       prefer-ip-address: true
     client:
       serviceUrl:
         defaultZone: http://eureka1.com:7001/eureka/,http://eureka1.com:7002/eureka/,http://eureka1.com:7003/eureka/
   
   zuul:
     routes:
     	#mydept是自己取的，通过serviceId和path分别指定真实服务名和其映射服务名
       mydept.serviceId: clouddemo-dept #代理哪个服务，同一该服务下所有服务实例的入口
       mydept.path: /mydept/**			#路由映射，隐藏真实服务名，对外暴露虚拟服务名
       #如果是订单服务，则可进行如下定义
       #myorder.serviceId: xxx
       #myorder.path:/myorder/**
   ```

4. 在启动类上添加 `@EnableZuulProxy`

   ```java
   package top.zhenganwen.clouddemo.zuul;
   
   import org.springframework.boot.SpringApplication;
   import org.springframework.boot.autoconfigure.SpringBootApplication;
   import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
   
   @SpringBootApplication
   @EnableZuulProxy
   public class ZuulApplication {
   
       public static void main(String[] args) {
           SpringApplication.run(ZuulApplication.class, args);
       }
   }
   ```

5. 测试

   1. 启动3个 `eureka server`

   2. 启动 `clouddemo-provider`

   3. 访问 `localhost:8001/dept/get/1`

      这种访问方式就是之前没使用 `zuul`时，服务调用方通过 `eureka server`获取服务实例进而调用

   4. 启动 `clouddemo-zuul-gateway`

      访问 `localhost:9527/mydept/dept/get/1`，其中 `mydept`是对 `clouddemo-dept`的映射，这种访问方式就是把该服务下的所有服务实例又包了一层。服务调用方要调用 `clouddemo-dept`服务不再是直接查出服务实例（`8001`或 `8002`或 `8003`），而是调用网关 `localhost:9527/clouddemo-dept`或 `localhost:9527/dept`（后者将真实服务名做了一个映射，这就好比滴滴打车为了司机的隐私使用了虚拟拨号隐藏司机真实手机号）

> `zuul`也是作为一个微服务注册到 `eureka`：

![](http://zanwenblog.oss-cn-beijing.aliyuncs.com/18-8-2/55939936.jpg)

## zuul路由映射规则

上述中通过 `zuul`代理 `clouddemo-dept`服务从而统一该服务下所有入口（`8001、8002、8003`）之后，可以通过 `zuul服务URL+虚拟服务名+服务REST API`（如 `localhost:9527/mydept/dept/get/1`）。但是 `localhost:9527/clouddemo-dept/dept/get/1`也能访问，这违背了**一个服务唯一入口**的原则。如此我们需要关闭 `localhost:9527/clouddemo-dept`这个暴露真实服务名的入口（通过 `ignore-services`）：

```yaml
zuul:
  routes:
    mydept.serviceId: clouddemo-dept
    mydept.path: /mydept/**
  ignored-services: clouddemo-dept
```

重启之后，`localhost:9527/clouddemo-dept/dept/get/1`就调不通了。

如果你想将所有带有真实服务名的入口（如 `localhost:9527/clouddemo-order`、`localhost:9527/clouddemo-cart`）都关闭，可以将 `ignore-services`设为 `“*”`：

```yaml
zuul:
  routes:
    mydept.serviceId: clouddemo-dept
    mydept.path: /mydept/**
  ignored-services: "*"
```

你甚至还可以通过`prefix`在 `zuul服务URL`和 `虚拟服务名`之间加一个公共前缀：

```yaml
zuul:
  routes:
    mydept.serviceId: clouddemo-dept
    mydept.path: /mydept/**
  ignored-services: clouddemo-dept
  prefix: /anwen
```

这样一来你就只能通过 `localhost:9527/anwen/mydept/dept/get/1`来访问了