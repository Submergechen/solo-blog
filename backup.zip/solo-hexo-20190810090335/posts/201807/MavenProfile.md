title: Maven Profile
date: '2018-07-14 18:04:49'
updated: '2018-07-14 18:04:49'
tags: [Maven]
permalink: /articles/2018/07/14/1565048866244.html
---
![](https://images.pexels.com/photos/248159/pexels-photo-248159.jpeg?auto=compress&cs=tinysrgb&h=350)

<!-- more -->

## 什么是MavenProfile

在我们平常的java开发中，会经常使用到很多配制文件（`xxx.properties`，`xxx.xml`），而当我们在本地开发（dev），测试环境测试（test），线上生产使用（product）时，需要不停的去修改这些配制文件，次数一多，相当麻烦。现在，利用maven的filter和profile功能，我们可实现**在编译阶段简单的指定一个参数就能切换配制**，提高效率，还不容易出错.

profile**可以让我们定义一系列的配置信息**，然后**指定其激活条件**。这样我们就**可以定义多个profile**，然后**每个profile对应不同的激活条件和配置信息**，从而达到**不同环境使用不同配置信息**的效果。

##  Maven Profile入门

修改`demo-web`的`pom.xml` ：

```xml
<properties>
    <port>9105</port>
</properties>
<build>  
    <plugins>	     
        <plugin>
            <groupId>org.apache.tomcat.maven</groupId>
            <artifactId>tomcat7-maven-plugin</artifactId>
            <version>2.2</version>
            <configuration>
                <!-- 指定端口 -->
                <port>${port}</port>
                <!-- 请求路径 -->
                <path>/</path>
            </configuration>
        </plugin>
    </plugins>  
</build>
```

运行`tomcat7:run` ,发现运行结果是一样的，因为port是变量，而变量值是定义为9105。这其实就是我们之前学习的maven的变量。 



那我们现在思考一下，如果这个端口在开发时使用9105，如果在生产环境（或其他环境）为9205呢？如何解决值的动态切换呢？

这时我们修改`pom.xml`，增加`profile`定义

```xml
<profiles>
    <profile>
        <id>dev</id>
        <properties>
            <port>9105</port>
        </properties>
    </profile>
    <profile>
        <id>pro</id>
        <properties>
            <port>9205</port>
        </properties>
    </profile>  
</profiles>
```

执行命令 tomcat7:run -P pro  发现以9205端口启动；执行命令 tomcat7:run -P dev  发现以9105端口启动

`-P` 后边跟的是`profile的id`

如果我们只执行命令`tomcat7:run` ,也是以9105启动，因为我们一开始定义的变量值就是9105，就是在不指定profileID时的默认值.



## 切换数据库连接配置

### 编写不同环境的配置文件

（1）我们在`demo-dao`工程中`src/main/resources`下创建`filter`文件夹

（2）`filter`文件夹下创建`db_dev.properties` ，用于配置开发环境用到的数据库

```
env.jdbc.driver=com.mysql.jdbc.Driver
env.jdbc.url=jdbc:mysql://localhost:3306/pinyougoudb?characterEncoding=utf-8
env.jdbc.username=root
env.jdbc.password=123456
```

（3）`filter`文件夹下创建`db_pro.properties`，用于配置生产环境用到的数据库

```
env.jdbc.driver=com.mysql.jdbc.Driver
env.jdbc.url=jdbc:mysql://localhost:3306/pinyougoudb_pro?characterEncoding=utf-8
env.jdbc.username=root
env.jdbc.password=123456
```

（4）修改`properties`文件夹下的`db.properties` 

```
jdbc.driver=${env.jdbc.driver}
jdbc.url=${env.jdbc.url}
jdbc.username=${env.jdbc.username}
jdbc.password=${env.jdbc.password}
```

### 定义Profile

修改`pom.xml` 

```xml
<properties>
    <env>dev</env>
</properties>
<profiles>
    <profile>
        <id>dev</id>
        <properties>
            <env>dev</env>
        </properties>
    </profile>    
    <profile>
        <id>pro</id>
        <properties>
            <env>pro</env>
        </properties>
    </profile>
</profiles>
```

这里我们定义了2个profile，分别是开发环境和生产环境

### 资源过滤与变量替换

修改`pom.xml` ，在`build`节点中添加如下配置

```xml
<filters>
    <!-- 切换配置文件，默认env=dev -->
    <filter>src/main/resources/filters/db_${env}.properties</filter>
</filters>
<resources>
    <resource>
        <directory>src/main/resources</directory>
        <filtering>true</filtering>
    </resource>  		
</resources>
```

这里我们利用`filter`实现对资源文件(`resouces`) 过滤   `maven filter`可利用指定的`xxx.properties`中对应的`key=value`对资源文件中的`${key}`进行替换，最终把你的资源文件中的`username=${key}`替换成`username=value`

### 打包

在`demo-dao`工程 执行命令：`package -P pro` ,  解压生成的jar包，观察`db.properties`配置文件内容，已经替换为生产环境的值。

在`demo-service`工程 执行命令 `pageage`  ，解压生成的war包里的`demo-dao`的jar包，发现也是生成环境的值。

### 测试运行

- 连接生产数据库
  - 在`demo-dao` 工程执行命令：`install -P pro`
  - 在`demo-service`执行命令：`tomcat7:run` 
  - 在`demo-web`执行命令：`tomcat7:run`
- 连接开发数据库
  - 在`demo-dao` 工程执行命令：`install -P dev`  (或 install   )
  - 在`demo-service`执行命令：执行命令：`tomcat7:run` 
  - 在`demo-web`执行命令：`tomcat7:run`



## 切换注册中心连接配置

### 集中配置注册中心地址

（1）在`demo-common`工程中`properties`文件夹下创建`dubbox.properties` 

```
address=192.168.25.135:2181
```

（2）`spring`目录下创建spring配置文件 `applicationContext-dubbox.xml` 配置如下：

```xml
<dubbo:registry protocol="zookeeper" address="${address}"/>
```

（3）所有的**service**工程与**web**工程都要依赖`demo-common` . 并删除每个工程中关于注册中心地址的配置 

（4）安装`demo-common`到本地仓库，然后测试运行。 

### MavenProfile配置

（1）在`demo-common`工程中创建`filters`目录 ，目录下建立`dubbox_dev.properties`	

```
env.address=192.168.25.135:2181
```

（2）建立`dubbox_pro.properties`

```
env.address=192.168.25.136:2181
```

（3）修改`dubbox.properties` 

```
address=${env.address}
```

（4）修改`demo-common`的`pom.xml` 

```xml
<properties>
    <env>dev</env>	
</properties>
<profiles>
    <profile>
        <id>dev</id>
        <properties>
            <env>dev</env>
        </properties>
    </profile>
    <profile>
        <id>pro</id>
        <properties>
            <env>pro</env>
        </properties>
    </profile>
</profiles> 
.............................
<build>
    <filters>
        <filter>src/main/resources/filters/dubbox_${env}.properties</filter>
    </filters>
    <resources>
        <resource>
            <directory>src/main/resources</directory>
            <filtering>true</filtering>
        </resource>	
    </resources>	
</build>
```