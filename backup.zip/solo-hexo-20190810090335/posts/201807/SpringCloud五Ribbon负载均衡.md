title: SpringCloud（五）Ribbon负载均衡
date: '2018-07-31 00:53:24'
updated: '2018-07-31 00:53:24'
tags: [SpringCloud]
permalink: /articles/2018/07/31/1565048880583.html
---
# 概述

## 是什么

`Spring Cloud Ribbon`是基于`Netflix Ribbon`实现的一套**客户端** **负载均衡**工具

简单的说，Ribbon是Netflix发布的开源项目，主要功能是**提供客户端的软件负载均衡算法**，将NetFlix的中间层服务连接在一起.Ribbon客户端组件提供一系列完善的配置项如连接超时，重试等.简单的说，就是在配置文件中列出`Load Balancer`(简称LB)后面所有的机器，Ribbon会**自动的帮助你基于某种规则(如简单轮询，随机连接等)去连接这些机器**.我们也很容易使用Ribbon实现自定义的负载均衡算法.

## 能干嘛

LB,即负载均衡(Load Balance),在微服务或分布式集群中经常用的一种应用.负载均衡简单的说就是**将用户的请求平摊的分配到多个服务上**,从而达到系统的HA（高可用）.创建的负载均衡有软件`Nginx`,`LVS`,硬件`F5`等，相应的在中间件如:dubbo和SpringCLoud中均给我们提供了负载均衡（其中SpringCloud的负载均衡算法可以自定义）.

### 集中式LB

即**在服务的消费方和提供方之间使用独立的LB设施**(可以是硬件,如`F5`,也可以是软件,如`Nginx`),由该设施负责**把访问请求通过某种策略转发**至服务的提供方

### 进程内LB

将LB逻辑**集成到消费方**,消费方从服务注册中心获知有哪些地址可用,然后自己再从这些地址中选择出一个**合适**的服务器.

Ribbon就属于进程内LB,**它只是一个类库,集成于消费方进程**,消费方通过它来获取到服务提供方的地址.

## 官方资料

[Ribbon](https://github.com/Netflix/ribbon/wiki/Getting-Started)

---

# Ribbon初步配置

以 之前的 `clouddemo-consumer`工程为例，理解 **Ribbon是一套客户端的负载均衡工具**

1. 添加Ribbon组件依赖（ribbon依赖eureka客户端，eureka又依赖config）

```xml
<dependency>
     <groupId>org.springframework.cloud</groupId>
     <artifactId>spring-cloud-starter-ribbon</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-config</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-eureka</artifactId>
</dependency>

```

2. 添加 `eureka.client`配置，找服务先找 `eureka`：

```yaml
server.port: 80

eureka:
  client:
    serviceUrl:
      defaultZone: http://eureka1.com:7001/eureka/,http://eureka2.com:7002/eureka/,http://eureka3.com:7003/eureka/
    register-with-eureka: false #不是服务提供方，不需要注册
```

3. 对 `RestTemplate`远程访问工具的获取添加 `@LoadBalanced`：

```java
@Configuration
public class BeanConfiguration {

    @Bean
    @LoadBalanced
    public RestTemplate getRestTemplate() {
        return new RestTemplate();
    }
}
```

> **Ribbon是一套客户端的负载均衡工具**浮出水面了：这里**客户端**是 `clouddemo-consumer`工程，**负载均衡**通过 `@LoadBalanced`

4. `ribbon`集成在 `eureka`客户端，因此还需添加 `@EnableEurekaClient`

```java
package top.zhenganwen.clouddemoconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class ClouddemoConsumerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClouddemoConsumerApplication.class, args);
    }
}
```

5. 将原先通过 `localhost:8001`直接访问服务端改为通过服务名到 `eureka`找服务端：

```java
package top.zhenganwen.clouddemoconsumer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import top.zhenganwen.clouddemo.entity.Dept;

import java.util.List;

@RestController
@RequestMapping("dept")
public class DeptConsumerController {

//  private static final String URL_PREFIX= "http://localhost:8001";
    private static final String URL_PREFIX= "http://CLOUDDEMO-DEPT";

    @Autowired
    private RestTemplate restTemplate;

    @PostMapping("add")
    public Boolean add(Dept dept) {
        return restTemplate.postForObject(URL_PREFIX + "/dept/add", dept, Boolean.class);
    }
    @GetMapping("list")
    public List<Dept> list() {
        return restTemplate.getForObject(URL_PREFIX + "/dept/list", List.class);
    }

    @GetMapping("get/{id}")
    public Dept get(@PathVariable Long id) {
        return restTemplate.getForObject(URL_PREFIX + "/dept/get/" + id, Dept.class);
    }
}
```

6. 启动三个 `eureka`，然后启动 `clouddemo-provider`，最后启动 `clouddemo-consumer`

7. 测试 `clouddemo-consumer`

   1. `localhost/dept/list`:

   ```json
   [
       {
           deptno: 1,
           dname: "人事部",
           db_source: "test"
       },
       {
           deptno: 2,
           dname: "技术部",
           db_source: "test"
       },
       {
           deptno: 3,
           dname: "公关部",
           db_source: "test"
       },
       {
           deptno: 4,
           dname: "销售部",
           db_source: "test"
       }
   ]
   ```

   查看控制台日志：

   ```shell
   2018-07-30 20:09:58.415  INFO 9064 --- [p-nio-80-exec-2] c.netflix.loadbalancer.BaseLoadBalancer  : Client: CLOUDDEMO-DEPT instantiated a LoadBalancer: DynamicServerListLoadBalancer:{NFLoadBalancer:name=CLOUDDEMO-DEPT,current list of Servers=[],Load balancer stats=Zone stats: {},Server stats: []}ServerList:null
   2018-07-30 20:09:58.422  INFO 9064 --- [p-nio-80-exec-2] c.n.l.DynamicServerListLoadBalancer      : Using serverListUpdater PollingServerListUpdater
   2018-07-30 20:09:58.441  INFO 9064 --- [p-nio-80-exec-2] c.netflix.config.ChainedDynamicProperty  : Flipping property: CLOUDDEMO-DEPT.ribbon.ActiveConnectionsLimit to use NEXT property: niws.loadbalancer.availabilityFilteringRule.activeConnectionsLimit = 2147483647
   2018-07-30 20:09:58.442  INFO 9064 --- [p-nio-80-exec-2] c.n.l.DynamicServerListLoadBalancer      : DynamicServerListLoadBalancer for client CLOUDDEMO-DEPT initialized: DynamicServerListLoadBalancer:{NFLoadBalancer:name=CLOUDDEMO-DEPT,current list of Servers=[192.168.25.1:8001],Load balancer stats=Zone stats: {defaultzone=[Zone:defaultzone;	Instance count:1;	Active connections count: 0;	Circuit breaker tripped count: 0;	Active connections per server: 0.0;]
   },Server stats: [[Server:192.168.25.1:8001;	Zone:defaultZone;	Total Requests:0;	Successive connection failure:0;	Total blackout seconds:0;	Last connection made:Thu Jan 01 08:00:00 CST 1970;	First connection made: Thu Jan 01 08:00:00 CST 1970;	Active Connections:0;	total failure count in last (1000) msecs:0;	average resp time:0.0;	90 percentile resp time:0.0;	95 percentile resp time:0.0;	min resp time:0.0;	max resp time:0.0;	stddev resp time:0.0]
   ]}ServerList:org.springframework.cloud.netflix.ribbon.eureka.DomainExtractingServerList@6ff11bec
   ```

   从中可以捕获到负载均衡和服务路由痕迹

> Ribbon和Eureka整合后Consumer可以直接调用服务而不用再关心地址和端口号

---

# Ribbon负载均衡

## 架构图

Ribbon在工作时分成两步：

- 第一步选择`Eureka Server`,它优选选择在同一个区域内**负载较少**的server.
- 第二步再**根据用户指定策略**,从server取到的服务注册列表中**选择一个地址**.

其中Ribbon提供了多种策略:比如**轮询,随机,根据响应时间加权**.其中轮询是用户不指定策略时的默认执行策略。



我们将在已有架构基础之上再加两个服务：`clouddemo-provider2`、`clouddemo-provider3`，通过 `Ribbon`使得 `clouddemo-consumer`对 `CLOUDDEMO-DEPT`服务的访问在 `provider`、`provider2`、`provider3`三个服务实例之间做一个均衡：

![](http://zanwenblog.oss-cn-beijing.aliyuncs.com/18-7-30/27614622.jpg)

## 实操

1. 为新增的两个微服务创建各自独立的数据库 `dept_db2`、`dept_db3`，体会每个微服务可以有自己独立的数据存储，也是为了后面负载均衡效果演示。

   1. `dept_db2`:

   ```sql
   DROP TABLE IF EXISTS `dept`;
   CREATE TABLE `dept` (
     `deptno` bigint(20) NOT NULL AUTO_INCREMENT,
     `dname` varchar(255) DEFAULT NULL,
     `db_source` varchar(255) DEFAULT NULL,
     PRIMARY KEY (`deptno`)
   ) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
   INSERT INTO `dept` VALUES ('1', '人事部', 'dept_db2');
   ```

   2.`dept_db3`：

   ```sql
   DROP TABLE IF EXISTS `dept`;
   CREATE TABLE `dept` (
     `deptno` bigint(20) NOT NULL AUTO_INCREMENT,
     `dname` varchar(255) DEFAULT NULL,
     `db_source` varchar(255) DEFAULT NULL,
     PRIMARY KEY (`deptno`)
   ) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
   INSERT INTO `dept` VALUES ('1', '人事部', 'dept_db3');
   ```

2. 以`clouddemo-provider`为模板创建`clouddemo-provider2`、`clouddemo-provider3`两个子模块，以`clouddemo-provider2`为例：

   1. 复制 `pom`中的依赖
   2. 复制代码和配置文件
   3. 修改 `application.yml`
      1. 修改其中的端口号为 `8002`
      2. `spring.application.name`还是为 `clouddemo-dept`不要改变
      3. 修改数据源url为 `jdbc:mysql://localhost:3306/dept_db2  `
      4. 修改该服务实例在 `eureka`上注册的id：`instance-id: clouddemo-dept-8002`

   `clouddemo-provider3`参照此步骤创建

3. 依次启动 `eureka`集群、3个`provider`服务实例测试：

   1. 访问 `eureka1.com:7001`发现服务注册成功：

   ![](http://zanwenblog.oss-cn-beijing.aliyuncs.com/18-7-30/86091482.jpg)

   2. 启动 `clouddemo-consumer`，访问 `localhost/dept/get/1`并刷新多次次，根据`db_source`属性值发现数据分别是**轮询**从 `test`、`dept_db2`、`dept_db3`数据库查出的数据：

      1. 第一次

      ```json
      { deptno: 1, dname: "人事部", db_source: "dept_db3" }
      ```

      2. 第二次

      ```
      { deptno: 1, dname: "人事部", db_source: "dept_db2" }
      ```

      3. 第三次

      ```json
      { deptno: 1, dname: "人事部", db_source: "test" }
      ```

      4. 第四次

      ```json
      { deptno: 1, dname: "人事部", db_source: "dept_db3" }
      ```

> 现在可以发现 `@LoadBalanced`的作用了吧，这里的负载均衡策略我们没有提供，因此Ribbon使用了默认的轮询策略。
>
> 总结：Ribbon其实就是一个软负载均衡的**客户端组件**,
> 他可以和其他所需请求的客户端**结合使用**,**和eureka结合只是其中一个实例**

-----------

# Ribbon核心组件IRule

> IRule:根据特定算法中从服务列表中选取一个要访问的服务

## 官方提供

Ribbon为我们实现好的算法如下：

- `RoudRobinRule`，轮询
- `RandomRule`，随机
- `AvailabilityFilteringRule`，会先过滤掉由于**多次访问故障而处于断路器跳闸状态的服务**,还有**并发的连接数超过阈值**的服务,然后对**剩余**的服务列表按照**轮询**策略进行访问
- `WeightResponseTimeRule`，**根据平均响应时间算所有服务的权重**,响应时间越快服务**权重越大被选中 的概率越高**.刚启动时如果统计信息不足,则使用`RoudRobinRule`策略,等统计信息足够,会切换到`WeightedResponseTimeRule`
- `RetryRule`，先按照`RoundRobinRule`的策略获取服务,如果获取服务失败则在指定时间内会进行重试,获取可用的服务
  - 例如，当 `provider`、`provider2`、`provider3`正常运行时，采用轮询策略。此时如果 `provider2`宕机了， `provider2`还是会被轮询到（客户端会抛异常），但是在指定时间内发现多次重试均失败之后，会将 `provider2`从轮询列表中剔除。
- `BestAvailableRule`，会过滤掉由于多次访问故障而处于断路器跳闸状态的服务,然后选择一个**并发量最小**的服务
- `ZoneAvoidanceRule`，默认规则,复合判断server所在区域的性能和server的可用性选择服务器

> `Spring Cloud Ribbon`默认为我们装载了轮询策略，如果我们没有显示的声明，则采取轮询策略，如果需要更换成以上策略中的任意一个，则只需声明对应的 `bean`纳入Spring 管理即可：

```java
package top.zhenganwen.clouddemoconsumer.cfg;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class BeanConfiguration {

    @Bean
    @LoadBalanced
    public RestTemplate getRestTemplate() {
        return new RestTemplate();
    }
    
    @Bean
    public IRule getRule(){
        return RandomRule();	//调整策略为随机访问
    }
}
```

## 自定义实现

### 特定的微服务特定的策略

上述切换成官方提供的策略只需配置对应的 `bean`，但是如果我只想对 `CLOUDDEMO-DEPT`这一个微服务指定特定的策略，而其他微服务采用默认策略该如何呢？

1. 创建一个提供策略的配置类：

```java
package top.zhenganwen.rule;

import com.netflix.loadbalancer.IRule;
import com.netflix.loadbalancer.RandomRule;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyRule {

    @Bean
    public IRule getRule() {
        return new RandomRule();
    }
}
```

2. 在启动类上添加 `@RibbonClient`：
   1. `value`指定特定的服务
   2. `configuration`指定一个配置类，该类提供了对该特定服务使用的策略（此例中：对 `CLOUDDEMO-DEPT`服务使用随机访问策略）

```java
package top.zhenganwen.clouddemoconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import top.zhenganwen.rule.MyRule;

@SpringBootApplication
@EnableEurekaClient
@RibbonClient(value = "CLOUDDEMO-DEPT",configuration = MyRule.class)
public class ClouddemoConsumerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClouddemoConsumerApplication.class, args);
    }
}
```

> **注意**：官方警告，`configuration`指定的配置类（此例中是 `MyRule`）不能在 `@ComponentScan`所在包及其子包下。由于启动类的 `@SpringBootApplication`包含了该注解，因此上述的 `MyRule`没有在启动类所在包及其子包下。

最后别忘了访问 `localhost/dept/get/1`测试，观察 `db_source`属性值的变动规律

### 自定义Rule

需求：依旧使用轮询策略，但是要求每个服务器被调用5此后再轮询。即原来是一人一次过，改为一人5次过。

首先参考一下 `RandomRule`的源码：

```java
public class RandomRule extends AbstractLoadBalancerRule {
    Random rand = new Random();

    public RandomRule() {
    }

    @SuppressWarnings({"RCN_REDUNDANT_NULLCHECK_OF_NULL_VALUE"})
    public Server choose(ILoadBalancer lb, Object key) {
        //判断是否开启负载均衡
        if (lb == null) {
            return null;
        } else {
            //选择访问哪个服务器
            Server server = null;

            while(server == null) {
                if (Thread.interrupted()) {
                    return null;
                }
			   //获取该服务下服务实例列表
                List<Server> upList = lb.getReachableServers();
                //获取该服务的服务实例数量
                List<Server> allList = lb.getAllServers();
                int serverCount = allList.size();
                if (serverCount == 0) {
                    return null;
                }

                //随机出一个服务实例
                int index = this.rand.nextInt(serverCount);
                server = (Server)upList.get(index);
                
                if (server == null) {
                    Thread.yield();
                } else {
                    if (server.isAlive()) {
                        return server;
                    }

                    server = null;
                    Thread.yield();
                }
            }

            return server;
        }
    }

    public Server choose(Object key) {
        return this.choose(this.getLoadBalancer(), key);
    }

    public void initWithNiwsConfig(IClientConfig clientConfig) {
    }
}
```

可以看出 `choose(ILoadBalancer lb, Object key)`是定义策略的核心，**随机算法**选出服务实例只有两句：

```java
int index = this.rand.nextInt(serverCount);
server = (Server)upList.get(index);       
```

因此我们只需参考 `RandomRule`，修改其中**算法部分**即可写出定义的 **每五次轮询**策略：

```java
package top.zhenganwen.rule;

import com.netflix.client.config.IClientConfig;
import com.netflix.loadbalancer.AbstractLoadBalancerRule;
import com.netflix.loadbalancer.ILoadBalancer;
import com.netflix.loadbalancer.Server;

import java.util.List;

public class MyPollRule extends AbstractLoadBalancerRule {

    private int total;          //记录同一个实例被连续访问的词数
    private int currentIndex;   //记录当前被轮询的实例的索引

    public MyPollRule() {
        total = 0;
        currentIndex = 0;
    }

    @SuppressWarnings({"RCN_REDUNDANT_NULLCHECK_OF_NULL_VALUE"})
    public Server choose(ILoadBalancer lb, Object key) {
        //判断是否开启负载均衡
        if (lb == null) {
            return null;
        } else {
            //选择访问哪个服务器
            Server server = null;

            while(server == null) {
                if (Thread.interrupted()) {
                    return null;
                }
                //获取该服务下服务实例列表
                List<Server> upList = lb.getReachableServers();
                //获取该服务的服务实例数量
                List<Server> allList = lb.getAllServers();
                int serverCount = allList.size();
                if (serverCount == 0) {
                    return null;
                }

                //随机出一个服务实例
//                int index = this.rand.nextInt(serverCount);
//                server = (Server)upList.get(index);
                
                //如果连续访问没有超过5次，则返回当前正在轮询的服务实例，并将连续访问次数递增
                if (total < 5) {
                    server = upList.get(currentIndex);
                    total++;
                }else {
                    //如果连续访问达到5次，则索引递增，访问次数归零
                    currentIndex++;
                    total = 0;
                    //如果当前轮询服务实例是列表中的最后一个，则将索引归零
                    if (currentIndex >= serverCount) {
                        currentIndex = 0;
                    }
                    //这里server还是为null，因此进入while循环取下一个服务实例重新对访问次数计数
                }

                if (server == null) {
                    Thread.yield();
                } else {
                    if (server.isAlive()) {
                        return server;
                    }

                    server = null;
                    Thread.yield();
                }
            }

            return server;
        }
    }

    @Override
    public Server choose(Object key) {
        return this.choose(this.getLoadBalancer(), key);
    }

    @Override
    public void initWithNiwsConfig(IClientConfig clientConfig) {
    }
}
```

最后我们需要注册该 `bean`以启用它：

```java
package top.zhenganwen.rule;

import com.netflix.loadbalancer.IRule;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyRule {

    @Bean
    public IRule getRule() {
        return new MyPollRule();
    }
}
```

测试 `localhost/dept/get/1`，连续访问查看策略是否生效（观察 `db_source`属性值的变化）