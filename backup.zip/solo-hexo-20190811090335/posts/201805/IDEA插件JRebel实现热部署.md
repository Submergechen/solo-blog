title: IDEA插件JRebel实现热部署
date: '2018-05-14 22:00:00'
updated: '2018-05-14 22:00:00'
tags: [JRebel]
permalink: /articles/2018/05/14/1565048869325.html
---
# 一、下载JRebel插件
-   打开`InteliJ IDEA`，快捷键`ctrl+alt+s`打开设置面板，在左上角搜索`plugin`，并点击下载：

![](1.png)

-   下载完后重启`IDEA`以启用`JRebel`插件。

# 二、下载反向代理工具激活JRebel
-   下载地址:https://github.com/ilanyu/ReverseProxy/releases/tag/v1.0
-   下载对应你操作系统的工具。由于我是`win10 64位`，因此以我下载的`ReverseProxy_windows_amd64.exe`为例。
-   下载后点击运行，若有防火墙拦截注意放行，运行后会打开一个命令行窗口，不要管它

# 三、激活JRebel
-   打开`IDAE`，`ctrl+alt+s`打开设置面板，搜索`JRebel`，点击`JRebel`主菜单，在右侧点击激活按钮
-   填写激活信息如下：

![](2.png)

-   选择`I already have a license`选项卡
-   选择激活方式的第三种:`Connect to License Server`
-   第一行输入框格式为`http://127.0.0.1:8888/GUID`，其中`GUID`随便找个`GUID`在线生成器生成一个就行，这里提供一个:

```
88414687-3b91-4286-89ba-2dc813b107ce
```
-   第二行输入框填个邮箱格式的字符串就行。
-   同意协议，点击`Change license`

# 四、确认激活成功
-   还是打开`JRebel`插件主菜单，若发现路灯`VALID`，则说明激活成功

![](3.png)

-   点击上图中的`offline`，你会发现有效期为从此刻起180天左右，此刻便可离线使用`JRebel`180天，到期后重复此套方法即可。