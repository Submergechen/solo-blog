title: IDEA集成JRebel实现Tomcat/Maven热部署
date: '2018-05-22 22:00:00'
updated: '2018-05-22 22:00:00'
tags: [JRebel, Tomcat]
permalink: /articles/2018/05/22/1565048875016.html
---
# 安装JRebel插件并破解
-   相关教程见[IDEA插件JRebel实现热部署](http://www.zhenganwen.top/2018/05/14/IDEA%E6%8F%92%E4%BB%B6JRebel%E5%AE%9E%E7%8E%B0%E7%83%AD%E9%83%A8%E7%BD%B2/)

# 设置IDEA配置项
-   `ctrl shift a`搜索`Registry`，双击搜索结果中的`Registry...`，在弹出的面板中找到`compile.automake.when.app.running`选项并打上勾，然后点击`Close`关闭面板。
-   `ctrl alt s`，搜索`Compile`，在右侧面板中将`Build project automaticlly`和`Compile independent modules in parallel`

# Tomcat启动项
-   若使用使用Tomcat运行项目，需要在Tomcat配置面板中将`On 'Update' action:`和`on frame deactivation`均设置为`update classes and resources`
-   `View`->`Tool Windows`->`JRebel`，打开`JRebel`面板，把需要热部署的项目打上勾。
-   点击`JRebel`提供的`Debug`按钮即可

# Maven启动项
-   如果是tomcat插件，则在`View`->`Tool Windows`->`Maven Projects`中在对应的模块的`Plugins`下的`tomcat`下的`tomcat:run`右键选择`Debug Run with JRebel`。