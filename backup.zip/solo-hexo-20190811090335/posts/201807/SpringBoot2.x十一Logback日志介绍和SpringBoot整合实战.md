title: SpringBoot2.x（十一）Logback日志介绍和SpringBoot整合实战
date: '2018-07-21 23:40:26'
updated: '2018-07-21 23:40:26'
tags: [SpringBoot]
permalink: /articles/2018/07/21/1565048876403.html
---
本文将介绍新日志框架Logback以及SpringBoot如何整合Logback

<!-- more -->

文前分享一组挪威北极光：

![](https://res.cloudinary.com/simpleview/image/upload/c_fill,f_auto,h_702,q_65,w_1200/v1/clients/norway/norway_asset_import_bbtdjv7cv3_e7b59e62-eb6a-d851-501b94b3c4fc15f2.jpg)

![](https://res.cloudinary.com/simpleview/image/upload/c_fill,f_auto,h_290,q_64,w_580/v1/clients/norway/eafdb5bb_4574_4405_880f_698f93e862fd_5e3a73f6-b7b7-4b93-b54c-30bf97836396.jpg)

![](https://res.cloudinary.com/simpleview/image/upload/c_fill,f_auto,h_290,q_64,w_580/v1/clients/norway/Northern_lights_Reine_Lofoten_2000x1000_de355490-2807-4dc7-ac0c-bc254d514095.jpg)

![](https://res.cloudinary.com/simpleview/image/upload/c_fill,f_auto,h_290,q_64,w_580/v1/clients/norway/0f0e5077_50d5_4cdc_9869_a816ec61d623_8c7389bb-9a69-43fb-9d1c-6f82f173ed8f.jpg)

![](https://res.cloudinary.com/simpleview/image/upload/c_fill,f_auto,h_290,q_64,w_580/v1/clients/norway/Northern_lights_at_north_Cape_northern_norway_2_1_218bb402-0fa3-446a-9eb1-3db5bab8a42a.jpg)

![](https://res.cloudinary.com/simpleview/image/upload/c_fill,f_auto,h_290,q_64,w_580/v1/clients/norway/bdd72fb8_c2d4_4546_b6b0_992ed048a5ad_6a077ca6-d839-4b97-8da1-e027d6566b63.jpg)

![](https://res.cloudinary.com/simpleview/image/upload/c_fill,f_auto,h_290,q_64,w_580/v1/clients/norway/northern_lights_svalbard_northern_norway_nav_148278a1-00b8-4678-bc80-3f82b17c0d06.jpg)

![](https://res.cloudinary.com/simpleview/image/upload/c_fill,f_auto,h_300,q_64,w_600/v1/clients/norway/Hurtigruten_and_the_northern_lights_Troms_nav_86487008-0a09-4f0f-8180-2a005edcef10.jpg)

-----------

# 新日志框架LogBack介绍

常用处理java的日志组件有 `slf4j`,`log4j`,`logback`,`common-logging`等。

## logback介绍

基于`Log4j`基础上大量改良，不能单独使用，推荐配合日志框架`SLF4J`来使用。

**Logback**当前分成三个模块：`logback-core`,`logback-classic`和`logback-access`;`logback-core`是其它两个模块的**基础**模块

## Logback的核心对象

`Logger`：**日志记录器**
`Appender`：指定**日志输出的目的地**，目的地可以是**控制台**，**文件**
`Layout`：日志布局 **格式化日志信息的输出**



## log4j

我们使用 `log4j`时，通常在 `classpath`下增加一个 `log4j.properties`（`log4j`会默认加载该文件复写框架默认的日志配置）：

```properties
===========log4j示例===========		
### 设置###
log4j.rootLogger = debug,stdout,D,E

### 输出信息到控制抬 ###
log4j.appender.stdout = org.apache.log4j.ConsoleAppender
log4j.appender.stdout.Target = System.out
log4j.appender.stdout.layout = org.apache.log4j.PatternLayout
log4j.appender.stdout.layout.ConversionPattern = [%-5p] %d{yyyy-MM-dd HH:mm:ss,SSS} method:%l%n%m%n

### 输出DEBUG 级别以上的日志到=D://logs/error.log ###
log4j.appender.D = org.apache.log4j.DailyRollingFileAppender
log4j.appender.D.File = D://logs/log.log
log4j.appender.D.Append = true
log4j.appender.D.Threshold = DEBUG 
log4j.appender.D.layout = org.apache.log4j.PatternLayout
log4j.appender.D.layout.ConversionPattern = %-d{yyyy-MM-dd HH:mm:ss}  [ %t:%r ] - [ %p ]  %m%n

### 输出ERROR 级别以上的日志到=D://logs/error.log ###
log4j.appender.E = org.apache.log4j.DailyRollingFileAppender
log4j.appender.E.File =E://logs/error.log 
log4j.appender.E.Append = true
log4j.appender.E.Threshold = ERROR 
log4j.appender.E.layout = org.apache.log4j.PatternLayout
log4j.appender.E.layout.ConversionPattern = %-d{yyyy-MM-dd HH:mm:ss}  [ %t:%r ] - [ %p ]  %m%n 
```

## log4j.properties转logback.xml

对应的，`logback`也需要日志配置，会默认加载 `classpath`下的 `logback.xml`。

如果有 `log4j.properties`，可以通过在线转换工具直接转为 `logback.xml`：https://logback.qos.ch/translator/

---------

# SpringBoot2.x整合logback

## 官网介绍

[SpringBoot2.0.1日志配置](https://docs.spring.io/spring-boot/docs/2.1.0.BUILD-SNAPSHOT/reference/htmlsingle/#boot-features-logging)

Spring Boot使用[Commons Logging](https://commons.apache.org/logging)进行所有内部日志记录，但保留底层日志实现。 为`Java Util Logging`，`Log4J2`和`Logback`**提供了默认配置**。 在每种情况下，记录器都**预先配置为使用控制台输出，**并且**还提供可选的文件输出**。

**默认情况**下，如果引入了 `starter-xx`依赖，则使用**Logback**进行日志记录。并且会指定**适当的Logback路由**，以确保依赖了`Java Util Logging，Commons Logging，Log4J或SLF4`J的依赖库都能正常工作。 

### 格式化日志输出

SpringBoot提供的默认格式化输出如下

```
2014-03-05 10:57:51.112  INFO 45469 --- [           main] org.apache.catalina.core.StandardEngine  : Starting Servlet Engine: Apache Tomcat/7.0.52
2014-03-05 10:57:51.253  INFO 45469 --- [ost-startStop-1] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring embedded WebApplicationContext
2014-03-05 10:57:51.253  INFO 45469 --- [ost-startStop-1] o.s.web.context.ContextLoader            : Root WebApplicationContext: initialization completed in 1358 ms
2014-03-05 10:57:51.698  INFO 45469 --- [ost-startStop-1] o.s.b.c.e.ServletRegistrationBean        : Mapping servlet: 'dispatcherServlet' to [/]
2014-03-05 10:57:51.702  INFO 45469 --- [ost-startStop-1] o.s.b.c.embedded.FilterRegistrationBean  : Mapping filter: 'hiddenHttpMethodFilter' to: [/*]
```

- 输出内容分别是：
  - 日期和时间：毫秒精度，易于排序
  - 日志级别：`ERROR`>`WARN`>`INFO`>`DEBUG`>`TRACE` 
  - 进程ID
  -  `----`分隔符，用于区分实际日志消息的开始 
  - 线程名称：括在方括号中（可能会截断控制台输出） 
  - 记录器名称：这通常是**源类**名称（通常缩写）
  - **日志消息**

> `Logback`没有`FATAL`级别。 它被替换为`ERROR` 

### 调整控制台输出日志为DEBUG级别

默认情况下，SpringBoot只会在控制台输出 `INFO`及以上级别（`WARN`、`ERROR`）的日志。如果你想输出 `DEBUG`级别的日志，可以通过以下两种方法：

1. 在运行SpringBoot应用 `jar`包时指定 `--debug`参数：

```shell
java -jar myApp.jar --debug
```

2. 或者在你的 `application.properties`中添加 `debug=true`

### 输出日志到文件中

SpringBoot默认只将日志输出到控制台，如果你想也将它输出到文件中那么你可以在 `application.properties`中设置 `logging.file`输出到指定的文件中或设置`logging.path`输出到指定的目录下（可以是相对目录也可以是绝对目录）。

如 `logging.file=my.log`则会输出到 `classpath`下， `loggging.file=/var/log`则会输出日志到`/var/log`目录下（自动生成文件）。

你还可以通过`logging.file.max-size` 指定当设置输出日志到指定目录下时，日志文件大小达到多少就轮询创建新的日志文件。

### 调整各系统日志级别

所有支持 `logging`的系统（框架）都可以在`application.properties`中设置一个不同的日志级别：

```properties
logging.level.root=WARN
logging.level.org.springframework.web=DEBUG
logging.level.org.hibernate=ERROR
```

### 自定义日志系统配置文件

- 指定日志系统和其配置文件名称

如果你的应用引入了 `starter-xx`依赖，SpringBoot默认会采用 `logback`日志系统，如果你想使用 `log4j`或 `Java Util Logging`则需要配置 `org.springframework.boot.logging.LoggingSystem=Log4j2` 或 `org.springframework.boot.logging.LoggingSystem =JDK`

并且如果采用的 `logback`，则SpringBoot会默认加载 `classpath`下的`logback-spring.xml`或 `logback-spring.groovy`或 `logback.xml` 或 `logback.groovy`作为它的配置文件；如果采用的 `log4j2`则默认加载 `log4j2-spring.xml` 或 `log4j2.xml` ；如果采用的 `JDK`，则默认加载 `logging.properties `

- `logback-spring.xml`举例

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<configuration>

     <!-- ConsoleAppender-输出到控制台 -->
    <appender name="consoleApp" class="ch.qos.logback.core.ConsoleAppender">
        <layout class="ch.qos.logback.classic.PatternLayout">
            <pattern>
                %date{yyyy-MM-dd HH:mm:ss.SSS} %-5level[%thread]%logger{56}.%method:%L -%msg%n
            </pattern>
        </layout>
    </appender>

    <!-- RollingFileAppender-输出到文件，滚动策略：每过一段时间则新建文件保存输出日志 -->
    <appender name="fileInfoApp" class="ch.qos.logback.core.rolling.RollingFileAppender">
         <!-- 只输出INFO、WARN级别的日志 -->
        <filter class="ch.qos.logback.classic.filter.LevelFilter">
            <level>ERROR</level>
            <onMatch>DENY</onMatch>
            <onMismatch>ACCEPT</onMismatch>
        </filter>
        <encoder>
            <pattern>
                %date{yyyy-MM-dd HH:mm:ss.SSS} %-5level[%thread]%logger{56}.%method:%L -%msg%n
            </pattern>
        </encoder>
        <!-- 滚动策略 -->
        <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
            <!-- 路径 -->
            <fileNamePattern>app_log/log/app.info.%d.log</fileNamePattern>
        </rollingPolicy>
    </appender>

    <appender name="fileErrorApp" class="ch.qos.logback.core.rolling.RollingFileAppender">
         <!-- 只输出ERROR级别的日志 -->
        <filter class="ch.qos.logback.classic.filter.ThresholdFilter">
            <level>ERROR</level>
        </filter>
        <encoder>
            <pattern>
                %date{yyyy-MM-dd HH:mm:ss.SSS} %-5level[%thread]%logger{56}.%method:%L -%msg%n
            </pattern>
        </encoder>

        <!-- 设置滚动策略 -->
        <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
            <!-- 路径 -->
            <fileNamePattern>app_log/log/app.err.%d.log</fileNamePattern>
            <!-- 控制保留的归档文件的最大数量，超出数量就删除旧文件，假设设置每个月滚动，
            且<maxHistory> 是1，则只保存最近1个月的文件，删除之前的旧文件 -->
            <MaxHistory>1</MaxHistory>

        </rollingPolicy>
    </appender>
    <!-- 设置日志级别为INFO，输出到三个地方 -->
    <root level="INFO">  
        <appender-ref ref="consoleApp"/>
        <appender-ref ref="fileInfoApp"/>
        <appender-ref ref="fileErrorApp"/>
    </root>
</configuration>
```

- 个性化设置

| Spring Environment                  | System Property                 | Comments                                                     |
| ----------------------------------- | ------------------------------- | ------------------------------------------------------------ |
| `logging.exception-conversion-word` | `LOG_EXCEPTION_CONVERSION_WORD` | The conversion word used when logging exceptions.            |
| `logging.file`                      | `LOG_FILE`                      | If defined, it is used in the default log configuration.     |
| `logging.file.max-size`             | `LOG_FILE_MAX_SIZE`             | Maximum log file size (if LOG_FILE enabled). (Only supported with the default Logback setup.) |
| `logging.file.max-history`          | `LOG_FILE_MAX_HISTORY`          | Maximum number of archive log files to keep (if LOG_FILE enabled). (Only supported with the default Logback setup.) |
| `logging.path`                      | `LOG_PATH`                      | If defined, it is used in the default log configuration.     |
| `logging.pattern.console`           | `CONSOLE_LOG_PATTERN`           | The log pattern to use on the console (stdout). (Only supported with the default Logback setup.) |
| `logging.pattern.dateformat`        | `LOG_DATEFORMAT_PATTERN`        | Appender pattern for log date format. (Only supported with the default Logback setup.) |
| `logging.pattern.file`              | `FILE_LOG_PATTERN`              | The log pattern to use in a file (if `LOG_FILE` is enabled). (Only supported with the default Logback setup.) |
| `logging.pattern.level`             | `LOG_LEVEL_PATTERN`             | The format to use when rendering the log level (default `%5p`). (Only supported with the default Logback setup.) |
| `PID`                               | `PID`                           | The current process ID (discovered if possible and when not already defined as an OS environment variable). |