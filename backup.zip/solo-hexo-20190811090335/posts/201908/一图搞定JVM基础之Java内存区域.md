title: 一图搞定JVM基础之Java内存区域
date: '2019-08-06 08:39:34'
updated: '2019-08-06 08:39:34'
tags: [JVM]
permalink: /articles/2019/08/06/1565051974780.html
---
![](https://img.hacpai.com/bing/20190224.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

![Java Memory Area](https://user-gold-cdn.xitu.io/2019/8/3/16c578e35039e8c0?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)