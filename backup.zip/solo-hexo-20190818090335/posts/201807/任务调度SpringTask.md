title: 任务调度SpringTask
date: '2018-07-14 02:11:49'
updated: '2018-07-14 02:11:49'
tags: [JavaEE, Spring]
permalink: /articles/2018/07/14/1565048858265.html
---
# 任务调度SpringTask

## 什么是任务调度

在企业级应用中，经常会制定一些“计划任务”，即**在某个时间点做某件事情**，**核心是以时间为关注点**，即在一个特定的时间点，系统执行指定的一个操作。常见的任务调度框架有*Quartz*和*SpringTask*等。

## SpringTask入门小Demo

创建模块`pinyougou-task-service`,添加配置文件`applicationContext-task.xml`  ,内容如下：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:p="http://www.springframework.org/schema/p"
	xmlns:context="http://www.springframework.org/schema/context"
	xmlns:task="http://www.springframework.org/schema/task"	
	xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd
        http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd
        http://www.springframework.org/schema/task http://www.springframework.org/schema/task/spring-task-4.2.xsd">
	<context:component-scan base-package="com.pinyougou.task"/>
    <task:annotation-driven/>
</beans>
```

创建包`com.pinyougou.task`

编写类：

```java
@Component
public class SeckillTask {
	/**
	 * 刷新秒杀商品
	 */
	@Scheduled(cron="* * * * * ?")
	public void refreshSeckillGoods(){
		System.out.println("执行了任务调度"+new Date());		
	}		
}
```

执行后会看到控制台每秒都输出了当前时间，其中cron设置的为表达式，是执行的时间规则。

## Cron表达式

### Cron表达式格式

Cron表达式是一个字符串，字符串以5或6个空格隔开，分为6或7个域，每一个域代表一个含义，Cron有如下两种语法格式： 

（1）`Seconds Minutes Hours DayofMonth Month DayofWeek Year`

（2）`Seconds Minutes Hours DayofMonth Month DayofWeek`

每一个域可出现的字符如下： 

- `Seconds`:可出现"`, - * /`"四个字符，有效范围为0-59的整数 
- `Minutes`:可出现"`, - * /`"四个字符，有效范围为0-59的整数 
- `Hours`:可出现"`, - * /`"四个字符，有效范围为0-23的整数 
- `DayofMonth`:可出现"`, - * / ? L W C`"八个字符，有效范围为1-31的整数 
- `Month`:可出现"`, - * /`"四个字符，有效范围为1-12的整数或JAN-DEc 
- `DayofWeek`:可出现`", - * / ? L C #`"八个字符，有效范围为1-7的整数或SUN-SAT两个范围。1表示星期天，2表示星期一， 依次类推 
- `Year`:可出现"`, - * /`"四个字符，有效范围为1970-2099年

每一个域都使用数字，但还可以出现如下特殊字符，它们的含义是： 

(1)`*`：表示匹配该域的**任意值**，假如在Minutes域使用*, 即表示每分钟都会触发事件。

(2)`?`:只能用在`DayofMonth`和`DayofWeek`两个域。它也匹配域的任意值，但实际不会。因为`DayofMonth`和 `DayofWeek`会相互影响。例如想在每月的20日触发调度，不管20日到底是星期几，则只能使用如下写法： `13 13 15 20 * ?`, 其中最后一位只能用`？`，而不能使用`*`，如果使用`*`表示不管星期几都会触发，实际上并不是这样（`？`表示**放弃指定**）。 

(3)`-`:表示**范围**，例如在`Minutes`域使用`5-20`，表示从5分到20分钟每分钟触发一次 

(4)`/`：表示在**起始时间开始触发**，然后**每隔固定时间触发一次**，例如在`Minutes`域使用`5/20`,则意味着5分钟开始触发一次，而25，45等分别触发一次. 

(5)`,`:表示列出**枚举值**值。例如：在`Minutes`域使用`5,20`，则意味着在5和20分每分钟触发一次。 

(6)`L`:表示**最后**，**只能**出现在`DayofWeek`和`DayofMonth`域，如果在`DayofWeek`域使用`5L`,意味着在最后的一个星期四触发。 

(7)`W:` 表示**有效工作日(周一到周五)**,**只能**出现在`DayofMonth`域，系统将在离指定日期的最近的有效工作日触发事件。例如：在 `DayofMonth`使用`5W`，如果5日是星期六，则将在最近的工作日：星期五，即4日触发。如果5日是星期天，则在6日(周一)触发；如果5日在星期一 到星期五中的一天，则就在5日触发。另外一点，**W的最近寻找不会跨过月份** 

(8)`LW`:这两个字符可以连用，表示在**某个月最后一个工作日**，即**最后一个星期五**。 

(9)`#`:用于确定**每个月第几个星期几**，**只能**出现在`DayofMonth`域。例如在`4#2`，表示某月的**第二个星期三**。

### Cron表达式例子

- `0 0 10,14,16 * * ?` 每天上午10点，下午2点，4点 
- `0 0/30 9-17 * * ?` 朝九晚五工作时间内每半小时 
- `0 0 12 ? * WED` 表示每个星期三中午12点 
- "`0 0 12 * * ?`" 每天中午12点触发 
- "`0 15 10 ? * *`" 每天上午10:15触发 
- "`0 15 10 * * ?`" 每天上午10:15触发 
- "`0 15 10 * * ? *`" 每天上午10:15触发 
- "`0 15 10 * * ? 2005`" 2005年的每天上午10:15触发 
- "`0 * 14 * * ?`" 在每天下午2点到下午2:59期间的每1分钟触发 
- "`0 0/5 14 * * ?`" 在每天下午2点到下午2:55期间的每5分钟触发 
- "`0 0/5 14,18 * * ?`" 在每天下午2点到2:55期间和下午6点到6:55期间的每5分钟触发 
- "`0 0-5 14 * * ?`" 在每天下午2点到下午2:05期间的每1分钟触发 
- "`0 15 10 ? * MON-FRI`" 周一至周五的上午10:15触发 
- "`0 15 10 15 * ?`" 每月15日上午10:15触发 
- "`0 15 10 L * ?`" 每月最后一日的上午10:15触发 
- "`0 15 10 ? * 6L`" 每月的最后一个星期五上午10:15触发 
- "`0 15 10 ? * 6L 2002-2005`" 2002年至2005年的每月的最后一个星期五上午10:15触发 
- "`0 15 10 ? * 6#3`" 每月的第三个星期五上午10:15触发

> 可直接上网搜**在线Cron表达式生产器**



## 秒杀商品列表的增量更新

每分钟执行查询秒杀商品表，将符合条件的记录并且缓存中不存在的秒杀商品存入缓存

```java
/**
	 * 刷新秒杀商品
	 */
@Scheduled(cron="0 * * * * ?")
public void refreshSeckillGoods(){
    System.out.println("执行了任务调度"+new Date());			
    //查询所有的秒杀商品键集合
    List ids = new ArrayList(redisTemplate.boundHashOps("seckillGoods").keys());
    //查询正在秒杀的商品列表		
    TbSeckillGoodsExample example=new TbSeckillGoodsExample();
    Criteria criteria = example.createCriteria();
    criteria.andStatusEqualTo("1");//审核通过
    criteria.andStockCountGreaterThan(0);//剩余库存大于0
    criteria.andStartTimeLessThanOrEqualTo(new Date());//开始时间小于等于当前时间
    criteria.andEndTimeGreaterThan(new Date());//结束时间大于当前时间		
    criteria.andIdNotIn(ids);//排除缓存中已经有的商品 		
    List<TbSeckillGoods> seckillGoodsList= seckillGoodsMapper.selectByExample(example);		
    //装入缓存 
    for( TbSeckillGoods seckill:seckillGoodsList ){
        redisTemplate.boundHashOps("seckillGoods").put(seckill.getId(), seckill);
    }
    System.out.println("将"+seckillGoodsList.size()+"条商品装入缓存");
}
```

## 过期秒杀商品的移除

每秒钟在缓存的秒杀上皮列表中查询过期的商品，发现过期则同步到数据库，并在缓存中移除该秒杀商品

```java
/**
	 * 移除秒杀商品
	 */
@Scheduled(cron="* * * * * ?")
public void removeSeckillGoods(){
    System.out.println("移除秒杀商品任务在执行");
    //扫描缓存中秒杀商品列表，发现过期的移除
    List<TbSeckillGoods> seckillGoodsList = redisTemplate.boundHashOps("seckillGoods").values();
    for( TbSeckillGoods seckill:seckillGoodsList ){
        if(seckill.getEndTime().getTime()<new Date().getTime()  ){//如果结束日期小于当前日期，则表示过期
            seckillGoodsMapper.updateByPrimaryKey(seckill);//向数据库保存记录
            redisTemplate.boundHashOps("seckillGoods").delete(seckill.getId());//移除缓存数据
            System.out.println("移除秒杀商品"+seckill.getId());
        }			
    }
    System.out.println("移除秒杀商品任务结束");		
}
```