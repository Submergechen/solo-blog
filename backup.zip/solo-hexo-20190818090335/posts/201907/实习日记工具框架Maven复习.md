title: 实习日记-工具框架-Maven复习
date: '2019-07-16 18:47:00'
updated: '2019-07-16 18:47:00'
tags: [Maven]
permalink: /articles/2019/07/16/1565048858963.html
---
# 安装和配置

## 环境变量

将解压后的`bin`目录配置到`path`中。主要是`mvn`命令，此命令的生命周期（后一个命令的执行将导致其前面的所有命令先执行一遍）如下：

- `mvn compile`，根据`src/main/java`目录编译生成包含字节码的`target`目录
- `mvn test`，执行`src/test/java`目录下的所有测试用例
- `mvn package`，将此项目打包（`jar`或`war`）放至`target`目录下
- `mvn install`，将此项目打包后的文件放至本地仓库中

> `mvn clean`则会将本项目的`target`目录清楚，有时你拿到的不是一个干净的maven项目（即别人编译、打包过），为了避免目标文件因运行环境不同而导致运行出错，建议先`mvn clean`并重新构建一下

## 配置文件

maven只有一个配置文件，即`maven_home/conf/settings.xml`

### 本地仓库

默认将C盘下用户主目录作为本地仓库的位置，如果你不想占C盘空间，可以设置如下：

```xml
<!-- localRepository
   | The path to the local repository maven will use to store artifacts.
   |
   | Default: ${user.home}/.m2/repository
  <localRepository>/path/to/local/repo</localRepository>
  -->
<localRepository>D:\Software\Maven\mvn_repo</localRepository>
```

### 中心仓库镜像

由于maven的中心仓库部署在国外的服务器上（下载依赖时如果在本地仓库中没有找到该依赖则会去中心仓库），网速不佳，因此可以使用国内的阿里云镜像：

````xml
<mirrors>
    <!-- mirror
     | Specifies a repository mirror site to use instead of a given repository. The repository that
     | this mirror serves has an ID that matches the mirrorOf element of this mirror. IDs are used
     | for inheritance and direct lookup purposes, and must be unique across the set of mirrors.
     |
    <mirror>
      <id>mirrorId</id>
      <mirrorOf>repositoryId</mirrorOf>
      <name>Human Readable Name for this Mirror.</name>
      <url>http://my.repository.com/repo/path</url>
    </mirror>
     -->

    <mirror>  
        <id>alimaven</id>  
        <mirrorOf>central</mirrorOf>  
        <name>aliyun maven</name> 
        <url>http://maven.aliyun.com/nexus/content/groups/public/</url>
    </mirror>  

</mirrors>
````

# 用Maven搭建一个web工程

如下使用`IDEA`创建一个带有骨架（在`src/java/main/`下添加了一个`webapp`用于存放视图文件）的Web工程

![](https://user-gold-cdn.xitu.io/2019/7/16/16bfa78a1be7fc4f?w=1213&h=827&f=png&s=173720)

然后我们创建`Servlet`，发现`HttpServelt`报红找不到该类，说明`servlet`相关`jar`包没有引入，于是在`pom.xml`中添加`servlet`和`jsp`依赖：

```xml
<dependencies>
    <dependency>
        <groupId>javax.servlet</groupId>
        <artifactId>servlet-api</artifactId>
        <version>2.5</version>
    </dependency>
    <dependency>
        <groupId>javax.servlet.jsp</groupId>
        <artifactId>jsp-api</artifactId>
        <version>2.0</version>
    </dependency>
</dependencies>
```

## 作用域

接着，可以在项目根目录的命令行下键入`tomcat:run`运行（maven默认内嵌了一个`tomcat6`），你会发现报错：自己写的`Servlet`无法转换成`HttpServelt`，这是因为`tomcat`应用已依赖了`servlet-api`和`jsp-api`，你在`pom`中又引入了一次，导致项目中这两个依赖都有两个`jar`包而产生了冲突。

由于我们只需要我们在`pom`中引入的`servlet-api`和`jsp-api`帮助我们度过编译期，而运行期不要将其编入`target`使用内嵌`tomcat`中的就可以了，因此我们可以将这两个依赖的生命周期（`scope`)设置为`provide`：

```xml
<dependencies>
    <dependency>
        <groupId>javax.servlet</groupId>
        <artifactId>servlet-api</artifactId>
        <version>2.5</version>
        <scope>provided</scope>
    </dependency>
    <dependency>
        <groupId>javax.servlet.jsp</groupId>
        <artifactId>jsp-api</artifactId>
        <version>2.0</version>
        <scope>provided</scope>
    </dependency>
</dependencies>
```

如此我们写的`servlet`和`jsp`便可以正常运行了。

如果不写`scope`则默认为`compile`，即作用域编译期、测试期、运行期；`test`则仅作用于测试代码`/src/test/java`的编译和运行（典型的如`junit`）；`runtime`表示被依赖项目无需参与编译，但后期的测试和运行需要其参与，如`jdbc`驱动

> 注：如果你使用的JDK是Java8，仍然会抛出异常，因为`tomcat6`不兼容Java8。解决如下

## Maven插件

有很多Maven插件可以集成进来帮助我们快速构建应用，比如上述`tomcat6`不兼容Java8的问题，我们就可以集成`tomcat7`插件：

```xml
<build>
    <plugins>
        <plugin>
            <groupId>org.apache.tomcat.maven</groupId>
            <artifactId>tomcat7-maven-plugin</artifactId>
            <version>2.2</version>
            <configuration>
                <port>8888</port>
            </configuration>
        </plugin>
    </plugins>
</build>
```

如此，键入`tomcat7:run`命令就能使该项目运行在端口为`8888`的`tomcat7`上，而键入`tomcat:run`命令则仍将此项目运行在默认`8080`端口的`tomcat6`上。

# 依赖冲突

```xml
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-context</artifactId>
    <version>5.0.2.RELEASE</version>
</dependency>
```

当你引入上述依赖时，由于`spring-context`自身依赖`5.0.2.RELEASE`版本的`core、beans、expression、aop`等依赖，又由于maven的传递性，当前项目也会引入这些依赖。此时，`context`称为直接依赖，后者称为传递依赖。

如果此时你再手动引入一个`4.2.4.RELEASE`版本的`beans`依赖：

```xml
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-context</artifactId>
    <version>5.0.2.RELEASE</version>
</dependency>
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-beans</artifactId>
    <version>4.2.4.RELEASE</version>
    <scope>compile</scope>
</dependency>
```

因为`context`和`beans`都依赖`core`，那么Maven间接依赖进来的`core`取哪个版本呢？

## 原则一：先进先留原则

> 如果两个直接依赖引入了两个不同版本的相同依赖，在`pom`中书写在前的将被保留。

也即，如果书写如下：

```xml
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-context</artifactId>
    <version>5.0.2.RELEASE</version>
</dependency>
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-beans</artifactId>
    <version>4.2.4.RELEASE</version>
    <scope>compile</scope>
</dependency>
```

那么引入的将是`5.0.2.RELEASE`版本的`spring-core`，否则将两者的书写顺序颠倒：

```xml
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-beans</artifactId>
    <version>4.2.4.RELEASE</version>
    <scope>compile</scope>
</dependency>
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-context</artifactId>
    <version>5.0.2.RELEASE</version>
</dependency>
```

引入的`spring-core`就是`4.2.4.RELEASE`版本的了。

## 原则二：依赖链短者保留

```xml
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-beans</artifactId>
    <version>4.2.4.RELEASE</version>
    <scope>compile</scope>
</dependency>
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-context</artifactId>
    <version>5.0.2.RELEASE</version>
</dependency>
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-core</artifactId>
    <version>5.0.2.RELEASE</version>
</dependency>
```

如上，无论`spring-beans`和`spring-context`的书写顺序如何，引入的`spring-core`均以第`15`行的`5.0.2.RELEASE`为准，因为通过依赖传递形成的依赖链最短。

## 原则三：使用exclusion排除依赖【推荐】

当发生依赖冲突时，我们可以将所有不想要的依赖通过`exclusion`显式声明的方式排除掉，这样最为直观。如，排除掉`4.2.4`版本的`spring-core`：

```xml
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-beans</artifactId>
    <version>4.2.4.RELEASE</version>
    <scope>compile</scope>
    <exclusions>
        <exclusion>
            <artifactId>org.springframework</artifactId>
            <groupId>spring-core</groupId>
        </exclusion>
    </exclusions>
</dependency>
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-context</artifactId>
    <version>5.0.2.RELEASE</version>
</dependency>
```

# 其他标签

## dependencyManagement

`dependencyManager`用来统一管理版本号，让子项目中引用一个依赖而不用显示的列出版本号。Maven会沿着父子层次向上走，直到找到一个拥有`dependencyManagement`元素的项目，然后它就会使用在这个`dependencyManagement`元素中指定的版本号。这样，一旦整个系统需要迭代升级，只需将定义在父项目的`dependencyManagement`中的版本号更换即可实现其所有子项目的依赖升级。

## properties

定义一些键值对，已达到复用、减少修改的目的。

# 父子工程

父工程通常不存放源代码，仅仅起到一个聚合的作用，将相关联的一些模块聚合在一起。需要注意一下几点：

- 父工程的`pom`中的`package`必须是`pom`

- 父工程通常通过定义`dependencyManagement`来控制子模块的依赖的版本号统一

- 父工程可在`dependency`中定义各子模块都可能用到的依赖，这些依赖会自动被子模块继承，也即子模块可省略在其`pom`中对这些依赖的引入

- 各子模块虽然继承同一父工程，但彼此之间没有任何直接关联关系，如果模块A需要用到模块B的功能，则需现将模块B`mvn install`到本地仓库，然后在模块A的`pom`中引入模块B的坐标。

  > 注：对于任何maven工程，无论是父工程还是子模块，要想其编译成功，其所有依赖必须要能在本地仓库或远程仓库中找得到

创建子模块的方法：右键父工程，选择`new module`。子模块可以在父工程的目录下，也可以和父工程同一目录，这没有任何影响。是否是父子工程需要看父工程`pom`中的`module`定义和子模块`pom`中的`parent`定义，子模块的`parent`中写父工程的`groupId、artifactId、version`，自己的`groupId`和`version`都将继承父工程的，只需自定义`artifactId`。