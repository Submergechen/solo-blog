title: 一图搞定JVM基础之Java内存区域
date: '2019-08-06 08:39:34'
updated: '2019-08-11 17:51:26'
tags: [JVM]
permalink: /articles/2019/08/06/1565051974780.html
---
![](https://img.hacpai.com/bing/20190224.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

![MemoryArea.png](https://img.hacpai.com/file/2019/08/MemoryArea-69a9fa13.png)
