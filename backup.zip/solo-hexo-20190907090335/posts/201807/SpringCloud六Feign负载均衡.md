title: SpringCloud（六）Feign负载均衡
date: '2018-07-31 18:41:06'
updated: '2018-07-31 18:41:06'
tags: [SpringCloud]
permalink: /articles/2018/07/31/1565048873435.html
---
<!-- more -->

# 概述

## Feigh是什么

Feign是一个**声明式**的Web服务**客户端**,使得**编写Web服务客户端变得非常容易**,**只需要创建一个接口,然后再上面添加注解即可**
[参考官网](https://github.com/OpenFeign/feign)

使用Feign能让编写WebService客户端更加简单,它的使用方法是定义一个接口,然后再上面添加注解,用时

- 也支持JAX-RS标准的注解.Feign
- 也支持可拔插式的编码器和解码器,
- Spring CLoud对Feign进行了封装,使其支持了Spring MVC标准注解和HttpMessageConverters.
- Feign可以与Eureka和RIbbon组合使用以支持负载均衡.

## Feign能干什么

Feign旨在**使编写Java HTTP客户端变得更容易**.

前面在使用`Ribbon+RestTemplate`时,利用`RestTemplate`对http请求的封装处理,形成了一套模板化的调用方法,但在实际开发中,由于对依赖服务的调用可能不止一处,**往往一个接口会被多处调用**,所以通常都会针对每个微服务自行**封装一些客户端类来包装这些依赖服务的调用**.所以,`Feign`在此基础上做了进一步的封装,由他来帮助我们定义和实现依赖服务接口的定义.在`Feign`的实现下,我们只需要创建一个接口并使用注解的方式来配置它(以前是`Dao`接口上面标注`Mapper`注解,现在是一个微服务接口上面标注一个`Feign`注解即可),即可**完成对服务提供方的接口绑定**,简化了使用`Spring Cloud Ribbon` 时,手动封装**服务调用客户端**的开发量.

这也是为了满足社区广大开发者面向接口编程的习惯。

--------

# 实操

先回顾一下 `clouddemo-consumer`工程中 `Controller`如何调用服务：

```java
package top.zhenganwen.clouddemoconsumer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import top.zhenganwen.clouddemo.entity.Dept;

import java.util.List;

@RestController
@RequestMapping("dept")
public class DeptConsumerController {

    private static final String URL_PREFIX= "http://CLOUDDEMO-DEPT";

    @Autowired
    private RestTemplate restTemplate;

    @PostMapping("add")
    public Boolean add(Dept dept) {
        return restTemplate.postForObject(URL_PREFIX + "/dept/add", dept, Boolean.class);
    }
    @GetMapping("list")
    public List<Dept> list() {
        return restTemplate.getForObject(URL_PREFIX + "/dept/list", List.class);
    }

    @GetMapping("get/{id}")
    public Dept get(@PathVariable Long id) {
        return restTemplate.getForObject(URL_PREFIX + "/dept/get/" + id, Dept.class);
    }
}
```

这里虽然 `RestTemplat`帮我们高度封装了 `http`操作，但是这并不符合原来 `Controller+Service`的编程习惯，我们还可以在此基础之上封装 `http://CLOUDDEMO-DEPT`、`/dept/add`等 `http`细节，只关注接口和方法。于是`Feign`粉墨登场了

`Feign`就是对 `Ribbon+RestTemplate`的再封装，`Feign`集成了 `Ribbon`（通过依赖传递可以看出：引入 `starter-feign`会包含 `starter-ribbon`的依赖），自然也能够和 `Rureka`客户端无缝整合

## 工程搭建

新建工程 `clouddemo-dept-feign`（与 `clouddemo-consumer`对比来看）：

1. 引入依赖：

```xml
<!--feign-->
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-feign</artifactId>
</dependency>
<!--eureka-->
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-config</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-eureka</artifactId>
</dependency>
<!--entity:Dept-->
<dependency>
    <groupId>top.zhenganwen</groupId>
    <artifactId>clouddemo-common</artifactId>
    <version>1.0-SNAPSHOT</version>
</dependency>
```

2. 配置 `eureka`集群信息：

```yaml
eureka:
  client:
    serviceUrl:
      defaultZone: http://eureka1.com:7001/eureka/,http://eureka2.com:7002/eureka/,http://eureka3.com:7003/eureka/
    register-with-eureka: false 
```

2. 不在编写 `RestTemplat+Ribbon(@LoadBalanced)`了，而是编写**接口+注解**（该类要能被 `@ComponentScan`扫描到）：

```java
@FeignClient(value = "CLOUDDEMO-DEPT")
public interface DeptService {

    @PostMapping("/dept/add")
    Boolean add(Dept dept);

    @GetMapping("/dept/list")
    List<Dept> list();

    @GetMapping("/dept/get/{id}")
    Dept get(@PathVariable("id") Long id);
}
```

> 其中 `value="CLOUDDEMO-DEPT"`是给`Ribbon`针对服务做负载均获取服务实例给 `RestTemplate`调用的（前面说过了：`Feign`集成了 `Ribbon`并高度封装了 `RestTemplate`）
>
> **易错点**：
>
> 1. 这里`@PathVariable`必须加上 `value`值，即使形参名 `Long id`和路径中的 `{id}`同名，也不可省略，否则之后会报错：`PathVariable annotation was empty on param 0`
> 2. 该类要能被 `@ComponentScan`扫描到，否则 `@EnableFeignClients`不会起作用

4. 在启动类上启用`Eureka`和 `Feign`组件：

```java
@SpringBootApplication
@EnableEurekaClient
@EnableFeignClients
public class ClouddemoFeginApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClouddemoFeginApplication.class, args);
    }
}
```

> 值得提醒的是 `Feign`不一定要和 `Eureka`一起使用，只不过本例使用了 `Eureka`
>
> `@EnableFeignClients`只会使能被 `@ComponentScan`扫秒到的添加了 `@FeignClient`的接口起作用

5. 将 `Feign`客户端（`DeptService`）当做 `bean`注入使用：

```java
package top.zhenganwen.clouddemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import top.zhenganwen.clouddemo.entity.Dept;
import top.zhenganwen.clouddemo.service.DeptService;

import java.util.List;

@RestController
@RequestMapping("dept")
public class DeptController {

    @Autowired
    private DeptService deptService;

    @PostMapping("add")
    public Boolean add(Dept dept) {
        return deptService.add(dept);
    }
    @GetMapping("list")
    public List<Dept> list() {
        return deptService.list();
    }

    @GetMapping("get/{id}")
    public Dept get(@PathVariable Long id) {
        return deptService.get(id);
    }
}
```

6. 依次启动 `Eureka Server`集群（3个）、`clouddemo-provider`、`clouddemo-provider2`，最后启动 `clouddemo-dept-feign`，测试调用和负载均衡发现：`localhost/dept/get/1`可以正常调用负载均衡被启用并且是默认的轮询策略。

7. 更改负载均衡策略（只需将相应的策略注册为 `bean`即可）：

```java
@Configuration
public class ConfigBeans {

    @Bean
    public IRule getRule() {
        return new RandomRule();
    }
}
```

​	重启后再次测试发现策略已变为随机访问

> 对比前的 `DeptConsumerController`可以发现，封装了 `RestTemplate`之后是完完全全面向接口编程了。并且 `Feign`还集成了 `Ribbon`，有关 `Ribbon`的配置如 `@EnableRibbon(value="CLOUDDEMO-DEPT",configuration=MyRule.class)`对特定服务启用负载均衡，使用 `MyRule`定义的策略等都被隐藏了。

## 将接口迁移到common工程

上述虽然实现了 `Feign`的使用，隐藏了 `RestTemplate`和 `Ribbon`的实现细节，但是如果将 `DeptService`写在 `clouddemo-dept-feign`中，如果其他消费者也要调 `CLOUDDEMO-DEPT`服务岂不是又要写一次。因此将 `FeignClient`写到 `common`工程以供复用才对。

1. 引入 `feign`依赖：

```xml
<!--feign-->
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-feign</artifactId>
</dependency>
```

2. 将 `DeptService`复制到`common`工程的 `top.zhenganwen.clouddemo.service`中，将 `common`工程重新打包安装到本地仓库
3. 删除 `clouddemo-dept-feign`中的`top.zhenganwen.clouddemo.service`文件夹
4. 修改`dept-feign`工程启动类注解：
   1. 添加 `@ComponentScan("top.zhenganwen.clouddemo")`，因为将 `DeptService`迁移到 `common`工程后，`dept-feing`工程的启动类上的注解 `@SpringBootApplication`是扫描不到的，因此要重新定义 `@ComponentScan`的扫描范围是 `common`和 `dept-feign`工程代码的根路径，即 `top.zhenganwen.clouddemo`
   2. 添加 `@EnableFeignClients(basePackages = {"top.zhenganwen.clouddemo.service"})`，指定 `FeignClient`所在包

```java
@SpringBootApplication
@EnableEurekaClient
@ComponentScan("top.zhenganwen.clouddemo")
@EnableFeignClients(basePackages = {"top.zhenganwen.clouddemo.service"})
public class ClouddemoFeginApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClouddemoFeginApplication.class, args);
    }
}
```

5. 再次测试

---------

# Feign和Ribbon的区别是什么

`Feign`只不过是集成了 `Ribbon`实现了负载均衡。但与 `Ribbon`相比，`Feign`只需要定义**服务绑定接口**且以**声明式**（接口方法添加 `@RequestMapping`、`@GetMapping`等，方法形参要与服务提供方接口中的保持一致）的方法，优雅而简单地实现了服务的调用：

```java
@FeignClient(value = "CLOUDDEMO-DEPT")
public interface DeptService {

    @PostMapping("/dept/add")
    Boolean add(Dept dept);

    @GetMapping("/dept/list")
    List<Dept> list();

    @GetMapping("/dept/get/{id}")
    Dept get(@PathVariable("id") Long id);
}
```