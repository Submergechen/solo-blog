title: SpringBoot+ActiveMQ+阿里大于实现短信发送微服务
date: '2018-06-21 04:11:31'
updated: '2018-06-21 04:11:31'
tags: [ActiveMQ, JavaEE, SpringBoot]
permalink: /articles/2018/06/21/1565048862438.html
---
> 不清楚阿里大于的，可参考我的上篇文章【短信验证码之阿里大于】
>
> 这是一个独立存在的工程，	和其他工程没有任何业务耦合，专门用来接收参数并发送短信



# 引入阿里大于SDK

```xml
<parent>
     <groupId>org.springframework.boot</groupId>
     <artifactId>spring-boot-starter-parent</artifactId>
     <version>1.4.0.RELEASE</version>
</parent>
<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-devtools</artifactId>
    </dependency>

    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-activemq</artifactId>
    </dependency> 
    <dependency>
         <groupId>com.aliyun</groupId>
         <artifactId>aliyun-java-sdk-dysmsapi</artifactId>
         <version>1.0.0-SNAPSHOT</version>
    </dependency>
    <dependency>
        <groupId>com.aliyun</groupId>
        <artifactId>aliyun-java-sdk-core</artifactId>
        <version>3.2.5</version>
    </dependency>
</dependencies>
```



# 修改SmsDemo

```java
package top.zhenganwen.sms

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
public class SmsUtil {

    //产品名称:云通信短信API产品,开发者无需替换
    static final String product = "Dysmsapi";
    //产品域名,开发者无需替换
    static final String domain = "dysmsapi.aliyuncs.com";

    //在application.properties中配置AK
    @Autowired
    private Environment environment;

    //发送短信
    public SendSmsResponse sendSms(String mobile,String signName,String templateCode,String param) throws ClientException {

        //可自助调整超时时间
        System.setProperty("sun.net.client.defaultConnectTimeout", "10000");
        System.setProperty("sun.net.client.defaultReadTimeout", "10000");

        //初始化acsClient,暂不支持region化
        IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou", environment.getProperty("accessKeyId"), environment.getProperty("accessKeySecret"));
        DefaultProfile.addEndpoint("cn-hangzhou", "cn-hangzhou", product, domain);
        IAcsClient acsClient = new DefaultAcsClient(profile);

        //组装请求对象-具体描述见控制台-文档部分内容
        SendSmsRequest request = new SendSmsRequest();
        //必填:待发送手机号
        request.setPhoneNumbers(mobile);
        //必填:短信签名-可在短信控制台中找到
        request.setSignName(signName);
        //必填:短信模板-可在短信控制台中找到
        request.setTemplateCode(templateCode);
        //可选:模板中的变量替换JSON串,如模板内容为"亲爱的${name},您的验证码为${code}"时,此处的值为
        request.setTemplateParam(param);

        //选填-上行短信扩展码(无特殊需求用户请忽略此字段)
        //request.setSmsUpExtendCode("90997");

        //可选:outId为提供给业务方扩展字段,最终在短信回执消息中将此值带回给调用者
        request.setOutId("yourOutId");

        //hint 此处可能会抛出异常，注意catch
        SendSmsResponse sendSmsResponse = acsClient.getAcsResponse(request);

        return sendSmsResponse;
    }
}
```



# 创建引导类

```java
package top.zhenganwen.sms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
```

- 添加配置文件`application.properties`

```xml
server.port=9090
spring.activemq.broker-url=tcp://47.98.xx.xx:61616
accessKeyId=xxx
accessKeySecret=xxx
```



# 创建消息监听类

- 当有消息（包含要发送的手机号、变量参数）入队时，调用阿里大于短信服务接口进行短信的发送

```java
package top.zhenganwen.sms;

import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.aliyuncs.exceptions.ClientException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;


import java.util.Map;

@Component
public class SmsSenderListener {

    @Autowired
    private SmsUtil smsUtil;

    @JmsListener(destination = "sms")
    public void sendSms(Map<String,String> map) {
        try {
            SendSmsResponse response = smsUtil.sendSms(map.get("mobile"),
                    map.get("signName"),
                    map.get("templateCode"),
                    map.get("param"));
            System.out.println(response.getCode());
            System.out.println(response.getMessage());
        } catch (ClientException e) {
            e.printStackTrace();
        }
    }
}
```

# 创建测试工程

## 引导类

```java
package top.zhenganwen.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
```



- 添加配置文件

```xml
server.port=8080
spring.activemq.broker-url=tcp://47.98.xx.xx:61616
```



## ActiveMQ调用微服务

- 模拟用户请求注册，调用微服务发送验证码

```java
package top.zhenganwen.test.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsMessagingTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
public class QueueController {

    @Autowired
    private JmsMessagingTemplate jmsMessagingTemplate;

    @RequestMapping("/sendMessage")
    public void sendMessage() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("mobile","xxx");
        map.put("signName","阿文");
        map.put("templateCode", "SMS_137666550");
        map.put("param","{\"code\":\"123456\"}");
        jmsMessagingTemplate.convertAndSend("sms",map);
    }
}
```

- 运行引导类，访问http://localhost:8088/sendMessage，手机号收到验证码，测试成功！