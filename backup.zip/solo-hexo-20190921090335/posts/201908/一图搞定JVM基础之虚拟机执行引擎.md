title: 一图搞定JVM基础之虚拟机执行引擎
date: '2019-08-06 08:40:31'
updated: '2019-08-11 17:50:46'
tags: [JVM]
permalink: /articles/2019/08/06/1565052030988.html
---
![](https://img.hacpai.com/bing/20190716.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

![VMExecutionEngine.png](https://img.hacpai.com/file/2019/08/VMExecutionEngine-2fcbe19e.png)
