title: Hadoop 2.x HA（高可用） 集群实战
date: '2019-09-27 10:30:25'
updated: '2019-09-28 12:05:58'
tags: [Hadoop]
permalink: /articles/2019/09/27/1569551425024.html
---
![](https://img.hacpai.com/bing/20171225.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

[HadoopHAHighAvailability.pdf.zip](https://img.hacpai.com/file/2019/09/HadoopHAHighAvailability.pdf-f85fc8cd.zip)

![HadoopHAHighAvailability.png](https://img.hacpai.com/file/2019/09/HadoopHAHighAvailability-349333ac.png)



