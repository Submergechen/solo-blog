title: 跨域解决方案CORS
date: '2018-07-10 19:37:11'
updated: '2018-07-10 19:37:11'
tags: [JavaEE]
permalink: /articles/2018/07/10/1565048873230.html
---
# 跨域解决方案CORS



​	CORS是一个W3C标准，全称是"**跨域资源共享**"（*Cross-origin resource sharing*）。CORS需要浏览器和服务器同时支持。目前，所有浏览器都支持该功能，IE浏览器不能低于IE10。



​	它允许浏览器向跨源服务器，发出XMLHttpRequest请求，从而克服了AJAX只能同源使用的限制。整个CORS通信过程，都是浏览器自动完成，不需要用户参与。对于开发者来说，CORS通信与同源的AJAX通信没有差别，代码完全一样。**浏览器一旦发现AJAX请求跨源，就会自动添加一些附加的头信息，有时还会多出一次附加的请求**，但用户不会有感觉。因此，**实现CORS通信的关键是服务器。只要服务器实现了CORS接口，就可以跨源通信**。



## 请求过程 

![](http://zanwenblog.oss-cn-beijing.aliyuncs.com/18-7-10/92709917.jpg)

### Preflight Request

![](http://zanwenblog.oss-cn-beijing.aliyuncs.com/18-7-10/10495946.jpg)

### Preflight Response

然后服务器端给我们返回一个Preflight Response ：

![](http://zanwenblog.oss-cn-beijing.aliyuncs.com/18-7-10/52038672.jpg)

> 这个预请求和预响应的过程就像进别人办公室前的敲门和回应的“请进”。浏览器要事先知道服务器是否允许跨域请求。然后接下来才是正在业务所需的请求和响应



## 代码实现

### 服务器端设置响应头信息

#### 设置可被跨域请求的域

```java
response.setHeader("Access-Control-Allow-Origin", "http://localhost:9105");
```

> `response.setHeader("Access-Control-Allow-Origin", "*");`可接受任何域的跨域请求，这里的**域**是一个协议、域名和端口号的组合。
>
> *Access-Control-Allow-Origin*是**HTML5**中定义的一种解决资源跨域的策略。它是通过服务器端返回带有*Access-Control-Allow-Origin*标识的Response header，用来解决资源的跨域权限问题。
>
> **注意**：服务器接口方法设置此响应头之后，前端js就能跨域请求该接口了，**但是只能以GET的方式**



### 设置cookie可被读写

**CORS请求默认不发送Cookie和HTTP认证信息**。如果要把Cookie发到服务器，**一方面要服务器同意，指定Access-Control-Allow-Credentials字段**。**另一方面，开发者必须在AJAX请求中打开withCredentials属性**。否则，即使服务器同意浏览器发送Cookie，浏览器也不会发送。或者，服务器要求设置Cookie，浏览器也不会处理。 



服务器处理如下：

```java
response.setHeader("Access-Control-Allow-Credentials", "true");
```

跨域js请求如下：

```js
//添加商品到购物车
$scope.addToCart=function(){
	$http.get('http://localhost:9107/cart/addGoodsToCartList.do?itemId='
	+ $scope.sku.id +'&num='+$scope.num,{'withCredentials':true}).success(
			function(response){
				.......				 
			}				
	);		
}
```

> 注意，当使用`response`设置`Access-Control-Allow-Credentials`为`true`之后，前面`Access-Control-Allow-Origin`的值就不能是`*`，而只能是一个具体的域了，因为`cookie`是和域绑定的

## SpringMVC对CORS的支持

SpringMVC的版本在**4.2**或以上版本，**可以使用注解实现跨域**, 我们只需要在需要跨域的方法上添加注解`@CrossOrigin`即可 ：

```java
@CrossOrigin(origins="http://localhost:9105",allowCredentials="true")
@RequestMapping	
```

> `allowCredentials="true"`  可以缺省