title: SpringBoot2.x（十五）多环境配置
date: '2018-07-27 22:59:41'
updated: '2018-07-27 22:59:41'
tags: [SpringBoot]
permalink: /articles/2018/07/27/1565048879080.html
---
<!-- more -->

# SpringBoot对多环境配置的支持

对于多环境配置，你也许有过相关的了解，如 `maven profile`，目的就在于方便应用程序在运行环境对不同配置文件的切换。

有时我们在本机上开发，连接的是本机的测试数据库（`dev`）；而部署到测试（`test`）或生产环境（`pro`），连接的可能又是另外一个数据库。这时我们需要定义多个配置文件（如 `application.properties`，`application-test.properties`、`application-pro.properties`）并在其中配置相应环境下同一属性对应的不同值。

我们可以拿一个简单的 `web-starter`工程为例：

```xml
<parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>2.0.3.RELEASE</version>
    <relativePath/> <!-- lookup parent from repository -->
</parent>

<properties>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    <project.reporting.outputEncoding>UTF-8</project.reporting.outputEncoding>
    <java.version>1.8</java.version>
</properties>

<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>

    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
    </dependency>
</dependencies>

<build>
    <plugins>
        <plugin>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-maven-plugin</artifactId>
        </plugin>
    </plugins>
</build>
```

在 `resources`目录下创建对应三种运行环境（开发、测试、生产）的配置文件：

`application.properties`：

```properties
#local
url=localhost
```

`application-test.properties`：

```properties
#test
url=www.zhenganwen.top
```

`application-dev.properties`：

```xml
#pro
url=www.baidu.com
```

让我们来看一下使用 `@Value("${url}")`读取的是哪个配置文件值：

```java
@Value("${url}")
private String url;
@RequestMapping("testProfile")
public String testProfile() {
    return url;
}
```

这很简单，根据 SpringBoot 的默认加载`classpath`的 `application.properties`作为应用的全局属性配置，访问 `localhost:8080/testProfile`响应的自然是 `localhost`

那么如果在 `application.properties`中添加如下配置呢：

```properties
spring.profiles.active=test
```

重启应用后你将会看到响应 `www.zhenganwen.top`。没错，将会指定应用程序读取属性值时会优先到 `application.properties`中 `spring.profiles.active=xxx`指定的配置文件（也就是 `application-{xxx}.properties`）中读取属性对应的值，这就是 SpringBoot 对多环境配置的支持。

基于以上理论，你已经可以预料到当设置 `application.properties`中的 `spring.profiles.active=pro`之后，`/testProfile`响应的将会是 `www.baidu.com`