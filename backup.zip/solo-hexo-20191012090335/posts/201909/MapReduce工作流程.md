title: MapReduce工作流程
date: '2019-09-21 13:27:38'
updated: '2019-09-21 13:27:38'
tags: [Hadoop]
permalink: /articles/2019/09/21/1569043658446.html
---
![](https://img.hacpai.com/bing/20190227.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# MapReduce 工作流程

> 以示例程序 `wordcount`为例

![image.png](https://img.hacpai.com/file/2019/09/image-620e89ee.png)

## Map

### InputFormat

`InputFormat`会将我们指定的输入路径中的文件按照`block`（默认 128M）逻辑切分成若干切片（`split`，如果文件不足 128M 则单独为一个切片，如果满了128M但是不满128M*1.1也单独为一个切片），然后交给`RecordReader`进行处理，产出若干`key/value record`

### RecordReader

产出的`key/value record`会暂存在内存中的一块环形缓冲区中（逻辑上成环形），写入`record`时会从环形上的两个位置写入，一个位置写入`record`，一个位置写入`record`的索引`inde`，这样做的好处是：要想在环上找到一个`record`不用遍历数据量较大的`record`序列，而只用遍历数据量较小的`index`列表。

## Shuffle

### Ring Buffer & Excessive Writing & Combine

`MapTask`会根据输入的大数据源源不断的产出`record`，而环形缓冲的大小是有限的（假设是100M，此参数可配置），当环形缓冲的占用量达到`80%`（此参数可配置）时，就会对这`80%`的`record`进行一个全排序（准确的说是二次排序，先按照`partition`有序（见`Partitioner`），再按照`record`的`key`有序），如果你设置了`CombinerClass`那么同时会对`record`进行一个**合并**，最后写入磁盘（此过程称为**溢写**），形成一个首先分区号有序其次`key`有序的`record`序列；而剩下的`20%`则继续迎接后续写入的`record`。

### Merge Sort

这样输入的数据集就会分批次写入到硬盘中，形成多个批次内有序的`record`序列，然后再从硬盘中逐批读出这些序列进行一个归并排序（归并的过程中又可以应用`Combiner`做一个合并处理），最终产出该`MapTask`对应的分区号有序、同一分区内`record.key`有序的`record`序列，即将流入`Reducer`

## Reducer

### setNumReduceTask

`MapTask`的数量是由切片规则来决定的，输入的数据集会被切成多少片就会有多少个`MapTask`，每个`MapTask`都会产出一个分区号有序的`record`序列，而`ReducerTask`是在`Driver`中通过`setNumReducerTask`手动指定的，一般会和`Partitioner`返回的分区号（返回0则会由`ReduceTask1`处理并产出到`part-r-0000`）类别数保持一致。

### ReduceTask

`ReduceTask`会从所有的`MapTask`的产出中抓取出分区号和自己对应的`record`过来，例如上图中`ReduceTask1`会分别抓取`MapTask1`和`MapTask2`产出的`record`序列中分区号为`0`的部分，进行一个归并排序（过程中使用`GroupingComparator`进行分组，结果对应`Reducer#reduce`方法入参的`Iterable values`）并将结果序列中的元素（`Object key,Iterable values`）逐个交给`Reducer#reduce`进行处理，可以通过`context.write`写入到`output`对应分区号的`part-r-000x`中。
