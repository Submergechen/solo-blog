title: Nginx入门（二）之配置虚拟主机
date: '2018-03-11 04:37:09'
updated: '2018-03-11 04:37:09'
tags: [Nginx]
permalink: /articles/2018/03/11/1565048864194.html
---
配置虚拟主机
===

>就是在一台服务器启动多个网站。
 
+   如何区分不同的网站：
    1.  域名不同
    2.  端口不同
    
通过端口区分不同虚拟机
---
+   查看Nginx的配置文件(/usr/local/nginx/conf/nginx.conf)
    ```    
    events {
        worker_connections  1024;
    }
    
    
    http {
        include       mime.types;
        default_type  application/octet-stream;
    
        #log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
        #                  '$status $body_bytes_sent "$http_referer" '
        #                  '"$http_user_agent" "$http_x_forwarded_for"';
    
        #access_log  logs/access.log  main;
    
        sendfile        on;
        #tcp_nopush     on;
     #keepalive_timeout  0;
         keepalive_timeout  65;
     
         #gzip  on;
     
     #一个server节点就是一个虚拟主机
         server {
             listen       80;
             server_name  localhost;
     
             #charset koi8-r;
     
             #access_log  logs/host.access.log  main;
     #html是nginx安装目录下的html目录
             location / {
                 root   html;
                 index  index.html index.htm;
             }
         }
     }

    ```
+   可以配置多个server，配置了多个虚拟主机。
    ``` 
    server {
        listen       80;
        server_name  localhost;

        #charset koi8-r;

        #access_log  logs/host.access.log  main;

        location / {
            root   html;
            index  index.html index.htm;
        }
    }
    server {
        listen       81;
        server_name  localhost;

        #charset koi8-r;

        #access_log  logs/host.access.log  main;

        location / {
            root   html-81;
            index  index.html index.htm;
        }
    }

+   重新加载nginx配置文件
    ``` 
    [root@localhost nginx]# sbin/nginx -s reload
    ```

    ```
+   在nginx/下创建html-81文件夹
    ``` 
    cp -r html html-81
    ```
+   开放81端口
    1.  写入修改
    ``` 
    /sbin/iptables -I INPUT -p tcp --dport 81 -j ACCEPT 
    ```
    2.  保存修改
    ``` 
    /etc/init.d/iptables save
    ```
    3.  重启防火墙
    ``` 
    service iptables restart
    ```
+   访问81端口

---------

通过域名区分虚拟主机
===

>一个域名对应一个ip地址，一个ip地址可以被多个域名绑定。

+   本地测试可以修改hosts文件。
    修改window的hosts文件：（C:\Windows\System32\drivers\etc）
    可以配置域名和ip的映射关系，如果hosts文件中配置了域名和ip的对应关系，不需要走dns服务器。

+   将内容修改如下
    #这是我虚拟机上linux的IP地址
    192.168.80.128 www.test1.com
    192.168.80.128 www.test2.com
    
+   在nginx/下创建html-test1、html-test2文件夹
    ``` 
    cp -r html html-test1
    cp -r html html-test2
    ```
+   在Nginx的配置文件/nginx/conf/nginx.conf增加虚拟主机
    ``` 
    server {
        listen       80;
        server_name  www.test1.com;

        #charset koi8-r;

        #access_log  logs/host.access.log  main;

        location / {
            root   html-test1;
            index  index.html index.htm;
        }
    }
    server {
        listen       80;
        server_name  www.test2.com;

        #charset koi8-r;

        #access_log  logs/host.access.log  main;

        location / {
            root   html-test2;
            index  index.html index.htm;
        }
    }

    ```
+   重新加载nginx配置文件
    ``` 
    [root@localhost nginx]# sbin/nginx -s reload
    ```
+   访问www.test1.com和www.test2.com

------------