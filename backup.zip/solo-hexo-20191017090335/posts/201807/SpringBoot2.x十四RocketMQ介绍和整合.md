title: SpringBoot2.x（十四）RocketMQ介绍和整合
date: '2018-07-24 22:24:45'
updated: '2018-07-24 22:24:45'
tags: [SpringBoot]
permalink: /articles/2018/07/24/1565048879995.html
---
<!-- more -->

# 简介

`Apache RocketMQ`作为阿里开源的一款高性能、高吞吐量的分布式消息中间件

## 特点

- 在高压下1毫秒内响应未延迟超过99.6％。
- 适合金融类业务，高可用性跟踪和**审计**功能。
- 支持发布订阅模型，和点对点
- 支持拉`pull`和推`push`两种消息模式
- **单一队列百万消息**
- 支持单master节点，多master节点，多master多slave节点

## 概念

- `Producer`:消息生产者

- `Producer Group`:消息生产者组，**发送同类消息**的一个消息生产组

- `Consumer`:消费者
- `Consumer Group`:消费**同个消息**的多个实例
- `Tag`:标签，子主题（二级分类）,用于区分**同一个主题下的不同业务的消息**

- `Topic`:主题（发布点阅）
- `Message`：消息
- `Broker`：**MQ程序**，接收生产的消息，提供给消费者消费的程序
	 `Name Server`：给生产者和消费者**提供路由信息**，提供**轻量级的服务发现和路由**	

## 学习资料

[官网](http://rocketmq.apache.org/docs/quick-start/)

[阿里中间件团队博客 ](http://rocketmq.apache.org/)

[分布式开放消息系统(RocketMQ)的原理与实践](https://www.jianshu.com/p/453c6e7ff81c)

# 安装和部署

## 前提环境

- `64bit OS, Linux/Unix/Mac`
- `64bit JDK 1.8+`

## Getting Started

[Getting Started](http://rocketmq.apache.org/docs/quick-start/)

### 下载安装包

>  此二进制安装包可直接解压运行

创建安装目录（`/export/servers`是我存放服务端应用的目录）：

```shell
[root@izbp18kejuoa2rnvbzgg6tz ~]# cd /export/servers
[root@izbp18kejuoa2rnvbzgg6tz servers]# mkdir rocketmq
```

下载安装包到此目录并解压：

```shell
[root@izbp18kejuoa2rnvbzgg6tz rocketmq]# https://www.apache.org/dyn/closer.cgi?path=rocketmq/4.2.0/rocketmq-all-4.2.0-bin-release.zip
[root@izbp18kejuoa2rnvbzgg6tz rocketmq]# unzip rocketmq-all-4.2.0-bin-release.zip
```

> 如果找不到 `unzip`命令，则使用 `yum install unzip`

## 启动

进入 `bin`目录启动 `NameServer`（后台启动）：

```shell
[root@izbp18kejuoa2rnvbzgg6tz rocketmq]# cd bin
[[root@izbp18kejuoa2rnvbzgg6tz bin]# nohup sh mqnamesrv &
[3] 24383
[root@izbp18kejuoa2rnvbzgg6tz bin]# nohup: ignoring input and appending output to ‘nohup.out’

```

查看启动日志：

```shell
[root@izbp18kejuoa2rnvbzgg6tz bin]# nohup: ignoring input and appending output to ‘nohup.out’
tail -f nohup.out
Java HotSpot(TM) 64-Bit Server VM warning: MaxNewSize (131072k) is equal to or greater than the entire heap (131072k).  A new max generation size of 131008k will be used.
The Name Server boot success. serializeType=JSON
Java HotSpot(TM) 64-Bit Server VM warning: Using the DefNew young collector with the CMS collector is deprecated and will likely be removed in a future release
Java HotSpot(TM) 64-Bit Server VM warning: UseCMSCompactAtFullCollection is deprecated and will likely be removed in a future release.
Java HotSpot(TM) 64-Bit Server VM warning: MaxNewSize (131072k) is equal to or greater than the entire heap (131072k).  A new max generation size of 131008k will be used.
The Name Server boot success. serializeType=JSON
Java HotSpot(TM) 64-Bit Server VM warning: Using the DefNew young collector with the CMS collector is deprecated and will likely be removed in a future release
Java HotSpot(TM) 64-Bit Server VM warning: UseCMSCompactAtFullCollection is deprecated and will likely be removed in a future release.
Java HotSpot(TM) 64-Bit Server VM warning: MaxNewSize (131072k) is equal to or greater than the entire heap (131072k).  A new max generation size of 131008k will be used.
The Name Server boot success. serializeType=JSON
```

最后一行显示 `The Name Server boot success`则表示启动成功，按 `ctrl C`退出会话

如果报错如下：

```
VM warning: INFO: OS::commit_memory(0x00000006c0000000, 2147483648, 0) faild; error=’Cannot allocate memory’ (errno=12)
```

这是因为服务器内存不够，无法分配。你需要修改启动脚本 `bin/runserver.sh`,`bin/runbroker.sh`中的一行内容：

`runserver.sh`:

```sh
JAVA_OPT="${JAVA_OPT} -server -Xms128m -Xmx128m -Xmn128m -XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m"
```

`runbroker.sh`:

```sh
JAVA_OPT="${JAVA_OPT} -server -Xms128m -Xmx128m -Xmn128m"
```

这些 `JVM`运行参数可根据应用场景自行设置。

启动成功后，通过 `jps`命令（java提供的命令）可查看正在运行的java应用程序：

```shell
[root@izbp18kejuoa2rnvbzgg6tz bin]# jps
21636 NamesrvStartup
21723 Jps
```

接着启动 `broker`

```shell
[root@izbp18kejuoa2rnvbzgg6tz bin]# nohup sh mqbroker -n 172.0.0.1:9876 &
```

按 `ctrl c`退出会话

查看进程：

```shell
[root@izbp18kejuoa2rnvbzgg6tz bin]# jps
21921 BrokerStartup
21970 Jps
21636 NamesrvStartup
```

## 关闭

你可以使用 `bin/mqshutdown broker`,`bin/mqshutdown namesrv`来关闭

--------

# 可视化控制台

不像 `activemq`，启动后自带web控制台，`rocketmq`需自己下载可视化web控制台插件来查看运行状况。

[插件下载地址](https://github.com/apache/rocketmq-externals/archive/master.zip)，我将它下载到 `rocketmq`目录下并解压

```shell
[root@izbp18kejuoa2rnvbzgg6tz rocketmq]# wget https://github.com/apache/rocketmq-externals/archive/master.zip
[root@izbp18kejuoa2rnvbzgg6tz rocketmq]# unzip rocketmq-externals-master.zip
[root@izbp18kejuoa2rnvbzgg6tz rocketmq]# rm -rf rocketmq-externals-master.zip
```

将此项目中的 `rocketmq-console`文件夹（SpringBoot开发的web应用，即我们所需的rocketmq控制台）移出来：

```shell
[root@izbp18kejuoa2rnvbzgg6tz rocketmq]# cd rocketmq-externals-master
[root@izbp18kejuoa2rnvbzgg6tz rocketmq-externals-master]# mv rocketmq-console ..
[root@izbp18kejuoa2rnvbzgg6tz rocketmq-externals-master]# cd ..
[root@izbp18kejuoa2rnvbzgg6tz rocketmq]# ls
benchmark  bin  conf  lib  LICENSE  NOTICE  README.md  rocketmq-console
```

启动该项目前需编译打包该项目：

> 编译该项目前需安装 `maven`，并且可能需要联网下载依赖（你也可以在宿主机上打包好后上传到虚拟机上）

```shell
[root@izbp18kejuoa2rnvbzgg6tz rocketmq]# cd rocketmq-console
[root@izbp18kejuoa2rnvbzgg6tz rocketmq-console]mvn clean package -Dmaven.test.skip=true
```

启动该项目：

```shell
[root@izbp18kejuoa2rnvbzgg6tz rocketmq-console]# java -jar target/rocketmq-console-ng-1.0.0.jar
```

接着访问 `192.168.25.136:8080`（`192.168.25.136`是这台虚拟机的内网IP）即可看到对应本机rocketmq服务的可视化控制台：

![](http://zanwenblog.oss-cn-beijing.aliyuncs.com/18-7-24/46642566.jpg)



**未完待续...**