title: SpringBoot2.x（十七）Actuator监控实战
date: '2018-07-29 18:20:13'
updated: '2018-07-29 18:20:13'
tags: [SpringBoot]
permalink: /articles/2018/07/29/1565048867538.html
---
<!-- more -->

# 什么是actuator

## 官方介绍

Spring Boot包含许多附加功能，可帮助您在将应用程序投入生产时**监视和管理应用程序**。 可以选择使用**HTTP端点**或JMX来管理和监控您的应用程序，自动应用于审计，健康和指标收集;

> 一句话：springboot提供用于**监控和管理生产环境**的模块

[官方文档](https://docs.spring.io/spring-boot/docs/2.1.0.BUILD-SNAPSHOT/reference/htmlsingle/#production-ready)

## 用来干嘛

有时我们需要编写一个定时任务不断查看某应用程序的系统情况（如内存占用率、磁盘占用率、CPU使用率以及应用程序健康状况），当出现异常时发送短信或邮件通知项目经理等负责人及时作出补救措施以减少损失。

# actuator实战

## 引入依赖

```xml
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-actuator</artifactId>  
</dependency> 
```

这里以 `SpringMVC+Mybatis`应用程序为例启动应用程序，访问如下**HTTP端点**：

`localhost:8080/actuator`：

```json
{
    _links: {
        self: {
            href: "http://localhost:8080/actuator",
            templated: false
        },
        health: {
            href: "http://localhost:8080/actuator/health",
            templated: false
        },
        info: {
            href: "http://localhost:8080/actuator/info",
            templated: false
        }
    }
}
```

## 版本区别

SpringBoot1.x到2.x，`actuator`提供的端点的基础路径由 `/`变成了 `/actuator`，也是为了避免和应用程序的映射路径冲突，如 `/actuator/health`、`/actuator/info`

## 端点列表

默认情况下，`actuator`提供的端点只有三个：`/actuator`、`/actuator/info`、`/actuator/health`，这是出于安全考虑，因为有很多端点包含项目的配置信息如 `application.properties`中的数据库密码、项目的目录结构等。

我们可以通过设置 `management.endpoints.web.exposure.include=*`开启所有的端点，端点列表可参见 [官方说明](https://docs.spring.io/spring-boot/docs/current-SNAPSHOT/reference/htmlsingle/#production-ready-endpoints-enabling-endpoints)

## 常用端点

### 基本指标列表metrics

`/actuator/metrics`：

```json
{ 
    names: [ 
        "jvm.memory.max", 
        "jvm.gc.memory.promoted",
        "tomcat.cache.hit", 
        "tomcat.cache.access",
        "jvm.memory.used", 
        "jvm.gc.max.data.size",
        "jvm.memory.committed",
        "system.cpu.count",
        "logback.events",
        ...
```

通过此列表查看具体内容：`/actuator/metrics/{name}`，如查看 `jvm`最大内存情况 ：``/actuator/metrics/jvm.memory.max`：

```json
{ 
    name: "jvm.memory.max", 
    measurements: [ 
        { 
            statistic: "VALUE", 
            value: 3423600639 
        }
    ], 
    availableTags: [ 
        { 
            tag: "area", 
            values: [ 
                "heap", 
                "nonheap" 
            ] 
        }, 
        { 
            tag: "id", 
            values: [ 
                "Compressed Class Space", 
                "PS Survivor Space", 
                "PS Old Gen", 
                "Metaspace", 
                "PS Eden Space", 
                "Code Cache" ] 
        } 
    ] 
}
```

### 可配置的环境属性env

`/actuator/env`：

```json
properties: { 
    com.sun.management.jmxremote.authenticate: { value: "false" }, 
	java.runtime.name: { value: "Java(TM) SE Runtime Environment" }, 
	spring.output.ansi.enabled: { value: "always" }, 
	sun.boot.library.path: { value: "E:\java8\jdk\jre\bin" }, 
	java.vm.version: { value: "25.171-b11" }
	...
```

其中包含了环境的可配置信息，如数据库连接url和密码等

## 开启/关闭端点

有的端点如 `env`暴露了敏感信息如 数据库连接密码，因此我们可以通过 `management.endpoints.web.exposure.include`启用一些端点，而通过 `management.endpoints.web.exposure.exclude`关闭一些包含敏感信息的端点：

```
开启全部：management.endpoints.web.exposure.include=*
开启某个：management.endpoints.web.exposure.include=metrics
关闭某个：management.endpoints.web.exposure.exclude=env
```

当然你也可以通过设置防火墙添加IP白名单

## 管理和脚本监控

### SpringAdmin

[相关资料](https://www.cnblogs.com/ityouknow/p/8440455.html)

### 自定义脚本监控

CPU、内存、磁盘、nginx的http响应状态码200,404,5xx