title: Nginx入门（三）之反向代理
date: '2018-03-11 04:37:09'
updated: '2018-03-11 04:37:09'
tags: [Nginx]
permalink: /articles/2018/03/11/1565048864892.html
---
反向代理
===

正向代理
---
>局域网中的主机通过可以上网的代理服务器间接的上网，请求由无网的主机发出，代理主机将请求转发。——客户端

反向代理
---
>用户请求发送到反向代理服务器，反向代理服务器决定哪台服务器提供服务。返回代理服务器不提供服务。只是将请求转发。——服务器端

Nginx实现反向代理
---

+   两个域名指向同一台nginx服务器，用户访问不同的域名显示不同的网页内容。
    如两个域名是www.sian.com和www.sohu.com，nginx服务器使用虚拟机192.168.80.128(我的虚拟机上Linux的IP地址) 
    
    1.  安装两个tomcat，分别运行在8080和8081端口（在server.xml中将port都改一下，避免冲突）。
    2.  启动两个tomcat。
    3.  在本地hosts文件中增加域名解析
        ``` 
        192.168.80.128 www.sina.com
        192.168.80.128 www.sohu.com
        ```
    4.  反向代理服务器的配置：
        ``` 
        upstream tomcat1{
            server 192.168.80.128:8080;
        }
        server {
            listen       80;
            server_name  www.sohu.com;
    
            #charset koi8-r;
    
            #access_log  logs/host.access.log  main;
    
            location / {
                proxy_pass   http://tomcat1; #根据域名转发到相应的服务器
                index  index.html index.htm;
            }
        }
        
        upstream tomcat2 {
            server 192.168.80.128:8081;
        }
        server {
            listen       80;
            server_name  www.sina.com;
    
            #charset koi8-r;
    
            #access_log  logs/host.access.log  main;
    
            location / {
                proxy_pass   http://tomcat2;
                index  index.html index.htm;
            }
        }

        ```
    5.  重新加载nginx配置文件
        
        `[root@localhost nginx]# sbin/nginx -s reload`
       
        
    6.  访问www.sina.com、www.sohu.com
 
 
--------


负载均衡
===
>如果一个服务由多条服务器提供，需要把负载分配到不同的服务器处理，需要负载均衡。
   
    ``` 
    upstream tomcat2 {
    	server 192.168.80.128:8081;
    	server 192.168.80.128:8082;
      }

    ```
+   可以根据服务器的实际情况调整服务器权重。权重越高分配的请求越多，权重越低，请求越少。默认是都是1（即各轮流一次）

    ``` 
    upstream tomcat2 {
        server 192.168.25.148:8081;
        server 192.168.25.148:8082 weight=2;
    }
    
    ```

-----------

Nginx的高可用
===

>要实现nginx的高可用，需要实现备份机

什么是负载均衡高可用
---
+   nginx作为负载均衡器，所有请求都到了nginx，可见nginx处于非常重点的位置，如果nginx服务器宕机后端web服务将无法提供服务，影响严重
+   为了屏蔽负载均衡服务器的宕机，需要建立一个备份机。主服务器和备份机上都运行高可用（High Availability）监控程序，通过传送诸如“I am alive”这样的信息来监控对方的运行状况。当备份机不能在一定的时间内收到这样的信息时，它就接管主服务器的服务IP并继续提供负载均衡服务；当备份管理器又从主管理器收到“I am alive”这样的信息时，它就释放服务IP地址，这样的主服务器就开始再次提供负载均衡服务