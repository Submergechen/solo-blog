title: SpringCloud（二）SpringCloud入门概述
date: '2018-07-29 22:15:44'
updated: '2018-07-29 22:15:44'
tags: [SpringCloud]
permalink: /articles/2018/07/29/1565048876066.html
---
<!-- more -->

# 介绍

## 是什么

> 官方介绍：协调任何事项；简化分布式系统 
>
> 使用Spring Cloud，构建分布式系统不再复杂和容易出错。Spring Cloud为最常用的分布式系统模式提供了简单易用的编程模型，帮助开发者构建有弹性、可靠和协调的应用程序。Spring Cloud基于Spring Boot构建，让开发者轻松入门、快速提高工作效率。

SpringCloud，基于SpringBoot提供了一套微服务解决方案，包括服务注册于发现、配置中心、全链路监控、服务网关、负载均衡、熔断器等组件，除了基于NetFlix的开源组件做高度抽象封装之外，还有一些选型中立的开源组件。

SpringCloud利用SpringBoot的开发便利性巧妙地简化了分布式系统基础设置的开发，SpringCloud为开发人员提供了快速构建分布式系统的一些工具，包括配置管理、服务发现、断路器、路由、微代理、事件总线、全局锁、决策竞选、分布式会话等等，它们都易用SpringBoot的开发风格做到一键启动和部署。

> SpringCloud=分布式微服务架构下的一站式解决方案，是各个微服务架构落地技术的集合体，俗称微服务全家桶。

## 组件

![](https://spring.io/img/homepage/diagram-distributed-systems.svg)

## 去哪儿学

- [官网](http://projects.spring.io/spring-cloud/)

- [SpringCloud中文网](https://springcloud.cc/)

- [API](http://cloud.spring.io/spring-cloud-static/Dalston.SR1/)，[中文参考手册](https://springcloud.cc/spring-cloud-dalston.html)

- [中国社区](http://springcloud.cn/)，可供寻求疑问和交流

  

# 面试题

## SpringBoot和SpringCloud是什么关系

SpringBoot并没有重复造轮子，它只是将目前各家公司开发的比较成熟、经得起实际考验的服务框架组合起来，通过SpringBoot风格进行再封装、屏蔽掉了复制的配置和实现原理，最终给开发者留出一套简单易懂、易部署和易维护的分布式系统开发工具包。

SpringBoot专注于快速方便的开发单个个体微服务。

SpringCloud是关注全局的微服务协调治理框架，它将SpringBoot开发的一个个单体微服务整合并管理起来。

## Dubbo和SpringCloud，如何选型？

### RPC弊端

通过RPC框架，使得我们可以像调用本地方法一样地调用远程机器上的方法： 

1. 本地调用某个函数方法 
2. 本地机器的RPC框架把这个调用信息封装起来（调用的函数、入参等），序列化(json、xml等)后，通过网络传输发送给远程服务器 
3. 远程服务器收到调用请求后，远程机器的RPC框架反序列化获得调用信息，并根据调用信息定位到实际要执行的方法，执行完这个方法后，序列化执行结果，通过网络传输把执行结果发送回本地机器 
4. 本地机器的RPC框架反序列化出执行结果，函数return这个结果

dubbo只支持RPC调用。使得服务提供方与调用方在代码上产生了**强依赖**，**服务提供者需要不断将包含公共代码的jar包打包出来供消费者使用**。一旦打包出现问题，就会导致服务调用出错。dubbox，提供了更高效的RPC序列化方式和REST调用方式。

### 技术支持

Spring Cloud为微服务架构提供了更加全面的技术支持：

|              | Dubbo            | SpringCloud                  |
| ------------ | ---------------- | ---------------------------- |
| 服务注册中心 | Apache Zookeeper | Spring Cloud Netflix Eureka  |
| 服务调用方式 | RPC              | RSET API                     |
| 服务监控     | Dubbo-monitor    | Spring Boot Admin            |
| 断路器       | 不完善           | Spring Cloud Netflix Hystrix |
| 服务网关     | 无               | Spring Cloud Netflix Zuul    |
| 分布式配置   | 无               | Spring Cloud Config          |
| 服务跟踪     | 无               | Spring Cloud Sleuth          |
| 消息总线     | 无               | Spring Cloud Bus             |
| 数据流       | 无               | Spring Cloud Stream          |
| 批量任务     | 无               | Spring Cloud Task            |

最大的区别：**SpringCloud抛弃了Dubbo的RPC通信，采用的是基于HTTP的REST方式**。

这两种方式各有优劣。虽然从一定程度上来说，后者牺牲了服务调用的性能，但也避免了上面提到的原生RPC带来的问题。而且REST相比RPC更为灵活，服务提供方和调用方的依赖只依靠一纸契约，不存在代码级别的强依赖，这在强调快速演化的微服务环境下，显得更加合适。

### 品牌机与组装机

Spring Cloud的功能比dubbo更加强大，涵盖面更广，而且作为Spring的拳头项目，它也能够与Spring Framework、Spring Boot、Spring Data、Spring Batch等其他Spring项目完美融合，这些对于微服务而言是至关重要的。使用dubbo构建的微服务架构就像组装电脑，各环节我们的选择自由度很高，但是最终结果很有可能因为一条内存质量不行就点不亮了，总是让人不怎么放心，但是如果你是一名高手，那这些都不是问题；而Spring   Cloud就像品牌机，在Spring Sourc的整合下，**做了大量的兼容性测试，保证了机器拥有更高的稳定性**，但是如果要在使用非原装组件外的东西，就需要**对其基础有足够的了解**，在服务内部使用一个统一的技术框架，显然比把分散的技术组合到一起**更有效率**。

### 社区支持与更新力度

最为重要的是，dubbo停止了5年左右的更新，虽然2017.7重启了项目。对于技术发展的新需求，需要有开发者自行拓展升级（比如当当网弄出了dubbox），者对于很多想要采用微服务架构的中小软件组织，显然是不太合适的，中小公司没有这么强大的技术能力去修改dubbo源码+周边的一整套解决方案，并不是每一个公司都有阿里的大牛+真实的线上生产环境测试过。

### 问题域

2017.7dubbo的重启负责人**刘军**被问到二者的关系和业务上是否有冲突时的回答：

> 首先要明确的一点是Dubbo和Spring Cloud并不是完全的竞争关系，两者所解决的问题域并不一样：Dubbo的定位始终是一款RPC框架，而Spring Cloud的目标是微服务架构下的一站式解决方案。
>
> 如果非要比较的话，我觉得Dubbo可以类比到Netflix OSS技术栈，而Spring Cloud集成了Netflix作为分布式服务治理解决方案，但除此之外Spring Cloud 还提供了包括config、stream、security、sleuth等等分布式问题解决方案。
>
> 当前由于RPC协议、注册中心元数据不匹配等问题，在面临微服务基础框架选型时Dubbo与Spring Cloud是只能二选一，这也是为什么大家总是拿Dubbo和Spring Cloud作对比的原因之一。Dubbo之后会积极寻求适配到Spring Cloud生态，比如作为Spring Cloud的二进制通信方案来发挥Dubbo的性能优势，或者Dubbo通过模块化以及对http的支持适配到Spring Cloud。