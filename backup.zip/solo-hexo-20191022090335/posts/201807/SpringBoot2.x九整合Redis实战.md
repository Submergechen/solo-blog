title: SpringBoot2.x（九）整合Redis实战
date: '2018-07-21 01:51:03'
updated: '2018-07-21 01:51:03'
tags: [SpringBoot]
permalink: /articles/2018/07/21/1565048865389.html
---
1. Redis安装和配置
2. SpringBoot2.x整合redis
3. Redis工具类封装

<!-- more -->

# Redis安装和配置

## 下载

- windows用户：官方源码压缩包：https://redis.io/download#installation
- linux用户：

```shell
wget http://download.redis.io/releases/redis-4.0.9.tar.gz
tar xzf redis-4.0.9.tar.gz
cd redis-4.0.9
make
```

## 启动

- 启动服务端：`src/redis-server`
- 启动客户端：`src/redis-cli`

## redis.conf配置

### 客户端IP限制

redis服务端默认只能被本地客户端连接。如果你想通过外网连接，需要在 `redis.conf`中修改如下配置

```
bind 127.0.0.1 47.98.121.1  #多个IP以空格分隔
```

这样公网IP为 `47.98.121.1`的主机也可访问本机的redis服务了。

你也可以多配置几个 `bind`：

```
bind 127.0.0.1
bind 47.98.121.1
```

### 取消客户端IP限制

如果你想任意主机都能连接本机redis服务，那么你需要做如下两步配置：

1. 注释以 `bind`开头的行

```shell
#bind 127.0.0.1
#bind 47.98.121.1
```

2. `redis3.2`以后的版本还需要关闭保护模式（仍然是修改 `redis.conf`）：

```
protected-mode no
```

### 设置连接密码

如果你觉得任意主机都能连接本机redis不太安全，又不想把主机白名单写死（`bind`），那么你可以设置一个连接密码，在 `redis.conf`中通过 `/requirepass`搜索：

```shell
requirepass 123456	#在这里设置连接密码
```

----------

# SpringBoot2.x整合Redis

## 引入依赖

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-redis</artifactId>
</dependency>
```

## 添加整合配置

- application.properties

```properties
#=========redis基础配置=========
spring.redis.database=0
#默认通过172.0.0.1:6379连接redis
spring.redis.host=172.0.0.1
spring.redis.port=6379
spring.redis.password=xxx	//如果在服务端redis.conf中设置了requirepass则需要配置此项
# 连接超时时间 单位 ms（毫秒）
spring.redis.timeout=3000

#=========redis线程池设置=========
# 连接池中的最大空闲连接，默认值也是8。
spring.redis.pool.max-idle=200

#连接池中的最小空闲连接，默认值也是0。
spring.redis.pool.min-idle=200

# 如果赋值为-1，则表示不限制；pool已经分配了maxActive个jedis实例，则此时pool的状态为exhausted(耗尽)。
spring.redis.pool.max-active=2000

# 等待可用连接的最大时间，单位毫秒，默认值为-1，表示永不超时
spring.redis.pool.max-wait=1000
```

## opsForXXX

Operations for xxx（redis中的数据类型）

```java
@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringbootMybatisApplicationTests {

    @Autowired
	private StringRedisTemplate redisTemplate;
    
    @Test
    public void testSetVal() {
        redisTemplate.opsForValue().set("name", "anwen");
    }

    @Test
    public void testGetVal() {
        String name = redisTemplate.opsForValue().get("name");
        System.out.println(name);	//anwen
    }
}
```

- 注入 `StringRedisTemplate`
- 调用 `opsForXxx`或 `boundXxxOps`

---------

# Redis工具类封装

## json转换工具类

通过 `starter-web`引入 `jackson`依赖，编写json转换工具类

```java
package top.zhenganwen.springbootmybatis.util;

import java.io.IOException;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtils {

    private static ObjectMapper objectMapper = new ObjectMapper();
    
    //对象转字符串
    public static <T> String obj2String(T obj){
        if (obj == null){
            return null;
        }
        try {
            return obj instanceof String ? (String) obj : objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    //字符串转对象
    public static <T> T string2Obj(String str,Class<T> clazz){
        if (StringUtils.isEmpty(str) || clazz == null){
            return null;
        }
        try {
            return clazz.equals(String.class)? (T) str :objectMapper.readValue(str,clazz);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
```

## 封装redisTemplate

```java
package top.zhenganwen.springbootmybatis.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Repository;

import java.util.concurrent.TimeUnit;

@Repository
public class RedisClient {

    @Autowired
    private StringRedisTemplate redisTemplate;

    public boolean set(String key, String val) {
        try {
            redisTemplate.opsForValue().set(key, val);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public Object getStr(String key) {
        return key == null ? null : redisTemplate.opsForValue().get(key);
    }

    //TODO lIST、MAP结构的set和get

    /**
     * 功能描述：设置某个key过期时间
     *
     * @param key
     * @param time
     * @return
     */
    public boolean expire(String key, long time) {
        try {
            if (time > 0) {
                redisTemplate.expire(key, time, TimeUnit.SECONDS);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    /**
     * 功能描述：根据key 获取过期时间
     *
     * @param key
     * @return
     */
    public long getExpire(String key) {
        return redisTemplate.getExpire(key, TimeUnit.SECONDS);
    }


    /**
     * 递增
     *
     * @param key 键
     * @return
     */
    public long incr(String key, long delta) {
        return redisTemplate.opsForValue().increment(key, delta);
    }


    /**
     * 递减
     *
     * @param key   键
     * @param delta 要减少几
     * @return
     */
    public long decr(String key, long delta) {
        return redisTemplate.opsForValue().increment(key, -delta);
    }
}
```

## 测试

```java
@Test
public void testGetVal() {
    System.out.println(redisClient.getStr("name"));	//anwen
}
```





-----------

# Redis常用图形用户界面

*Redis Desktop Manager* ：[下载地址](https://redisdesktop.com/download)